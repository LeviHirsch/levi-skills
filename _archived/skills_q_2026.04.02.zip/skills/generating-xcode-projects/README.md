# Generating Xcode Projects Skill

Automates the generation of Xcode project files (`.xcodeproj`) from Swift source code using XcodeGen.

## What This Skill Does

This skill teaches Claude Code how to:
- Generate properly configured Xcode project files
- Avoid common configuration pitfalls (especially Info.plist conflicts)
- Use XcodeGen to create projects from YAML specifications
- Validate generated projects before building
- Test build to ensure everything works

## When to Use

Trigger this skill by asking Claude Code to:
- "Create an Xcode project"
- "Generate a .xcodeproj file"
- "Set up an iOS app project"
- "Make this into an Xcode project"

## Key Features

### Prevents Info.plist Conflicts

The skill automatically configures projects to avoid the common error:
```
Multiple commands produce '.../Info.plist'
```

This happens when both:
1. `GENERATE_INFOPLIST_FILE = YES` (auto-generate)
2. `INFOPLIST_FILE = path/Info.plist` (manual file)

The skill ensures only auto-generation is used with proper `INFOPLIST_KEY_*` settings.

### Validation Built-In

Includes a validation script that checks for:
- Info.plist configuration conflicts
- Unnecessary physical Info.plist files
- Missing deployment targets
- Missing Swift version settings

### Template-Based

Provides ready-to-use templates for:
- iOS apps (SwiftUI or UIKit)
- macOS apps
- Multi-platform apps
- Projects with unit tests
- Apps with entitlements or SwiftData

## How It Works

1. **Generate source files first** - Claude creates all Swift code
2. **Create project.yml** - Uses templates to configure the project
3. **Run XcodeGen** - Generates the `.xcodeproj` from YAML
4. **Validate** - Checks for common configuration issues
5. **Test build** - Verifies the project builds successfully

## Requirements

- **XcodeGen**: Install with `brew install xcodegen`
- **Xcode**: For building and running projects

## File Structure

```
generating-xcode-projects/
├── SKILL.md                    # Main skill instructions
├── PROJECT_TEMPLATE.md         # Configuration templates
├── scripts/
│   └── validate_project.sh     # Validation script
└── README.md                   # This file
```

## Example Usage

**User:** "Create an Xcode project for my iOS app"

**Claude will:**
1. Check if XcodeGen is installed
2. Create `project.yml` with proper settings
3. Run `xcodegen generate`
4. Run validation script
5. Test build with xcodebuild
6. Report success and provide `open <Project>.xcodeproj` command

## Troubleshooting

**"Command not found: xcodegen"**
- Install with: `brew install xcodegen`

**Build fails with Info.plist errors**
- The validation script should catch these before building
- Check that no physical Info.plist files exist
- Verify `GENERATE_INFOPLIST_FILE: YES` is set in project.yml

**Missing source files in project**
- Ensure source directories are listed in `sources:` array in project.yml
- Re-run `xcodegen generate`

## Why This Approach?

**Automated > Manual**: Manual project setup is error-prone and uses outdated patterns

**XcodeGen Benefits:**
- Project configuration as code
- Reproducible builds
- Version control friendly (YAML vs binary .xcodeproj diffs)
- Industry standard for iOS teams

**Prevents Configuration Drift**: Automation ensures modern best practices (auto-generated Info.plist) instead of legacy patterns (manual Info.plist files)

## Credits

Based on lessons learned from Xcode project configuration conflicts and best practices from the iOS development community.
