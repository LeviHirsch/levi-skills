# /spec extract — Constrained document extraction

Extract structured facts from files in `context/` without synthesis or recommendations. Produces a four-section quarantine document for user review before it feeds `/spec seed`.

## State machine

**Allowed from phases:** `interviewing` · `seeded` (with warning — re-running seed will be needed)
**Transitions to:** same phase (no phase change)
**Re-run behavior:** Allowed. New run replaces `latest_extract` in state.yaml. Old file remains in archive.

Read state.yaml first; validate phase. Write state.yaml on completion.

## What extract is for

Extract is *defensive*: it processes what exists without adding interpretation. The agent's job is to surface claims, not evaluate them. Forward-looking synthesis, recommendations, or speculative connections belong in `/spec explore` or the interview itself.

Distinction from related commands:
- **`/spec extract`** — `context/` files only, no synthesis, structured output, lowest contamination risk. Run this when you have imported source documents and want a clean quarantine before the interview or seed.
- **`/spec explore`** — broader scope (user-specified dirs/files beyond `context/`), interpretive synthesis allowed, advisory output. Run when you want the agent to make connections across project materials.
- **`/spec research`** — web-enabled, citations required. Run when the interview surfaces a factual question that needs external verification.

## Protocol

1. **Check prerequisites.** Read state.yaml. If phase is `seeded` or later, warn: "Running extract post-seed means the new findings won't be in the current `spec/spec.md` — you'll need to re-run `/spec seed`. Proceed?" Stop until confirmed.

2. **Identify input files.** List everything in `context/` (excluding `README.md`). If the directory is empty or contains only `README.md`, tell the user there are no context documents to extract and stop.

3. **Spawn Explore sub-agent.** Use `subagent_type: "Explore"` and `model: "sonnet"`. The prompt must include the **write-fallback instruction from SKILL.md principle 7**. Prompt:

   > You are performing a constrained fact-extraction pass. Your mandate is narrow: read each file listed below, extract what exists, and flag problems. Do NOT synthesize, recommend, or speculate about what should be done. Do NOT carry forward bad ideas — put them in Flagged.
   >
   > Files to read (all in `context/`):
   > `<list every file in context/ except README.md, with absolute paths>`
   >
   > Produce the file at `<absolute path: spec/archive/v<NNN>-YYYY-MM-DD-HHMM-extract.md>` with exactly these four sections and no others:
   >
   > ## Established facts
   > Claims from the documents that are concrete, specific, and internally consistent. One bullet per claim. Cite the source filename inline: `[from-docs: filename]`. Quote or tightly summarize — do not paraphrase loosely.
   >
   > ## Claims to verify
   > Assertions that are plausible but unverified, vague, aspirational, or stated without evidence. One bullet per claim. Cite source filename. Note WHY verification is needed (e.g., "no supporting data", "contradicts claim in X", "aspirational framing").
   >
   > ## Flagged problems
   > Holes, internal contradictions, wrong directions, unsupported assertions, or conflicts across documents. One bullet per problem. Cite all relevant filenames. Be specific about what conflicts with what.
   >
   > ## Discarded
   > Leave this section EMPTY. It is for the user to annotate — they will move items here after review. Do not pre-populate it.
   >
   > Do not add a fifth section. Do not write an executive summary. Do not make recommendations.
   >
   > Attempt the Write tool for the target path. If Write is denied, retry once; if still denied, include the full intended file content verbatim in your final reply inside a fenced code block labeled with the target absolute path, so the parent session can write it. Never report success without either having written the file or having dumped its full content.

4. **Verify the file exists.** After the sub-agent returns, check whether the archive file was actually written. If not, extract the dumped content from the sub-agent's reply and write it directly.

5. **User review gate.** Present a summary: count of established facts, claims to verify, and flagged problems. Tell the user:
   > "Open `spec/archive/<filename>` and annotate it before running `/spec seed`. For each item in `## Claims to verify`: move it to `## Established facts` (if confirmed) or `## Discarded` (if not relevant) with a one-line note. For each item in `## Flagged problems`: add a one-line note — keep, fix, or drop. The seed step will read this file automatically."

6. **Update state.yaml:** `latest_extract: <archive filename>`, `last_command: /spec extract`, `last_command_at: <timestamp>`. Phase unchanged.

7. **Propose commit:**
   ```
   git add spec/archive/<filename> spec/state.yaml
   git commit -m "spec: extract v<n>"
   ```
