# /spec collect — Find and import context documents

Survey specified directories for relevant files and import selected ones into `context/` with timestamped naming. This is a logistics step — it populates `context/` so that `/spec extract` can process it. Collect does not read file contents; it presents a curated candidate list for the user to select from.

## State machine

**Allowed from phases:** any (no phase restriction — logistics step)
**Transitions to:** same phase (no phase change)
**Re-run behavior:** Allowed. Each run may add new files; it never removes existing `context/` files.

No state.yaml field is tracked for collect. Proof that it ran is in `context/README.md`.

## What collect is for

Collect is the *import gate*: it bridges the gap between documents scattered in the filesystem and the curated `context/` directory that `/spec extract` processes. It is distinct from:

- **`/spec extract`** — processes what is already in `context/`. Run after collect.
- **`/spec explore`** — synthesizes across materials. Does not import files.
- Manual drop — the user can always bypass collect by placing files in `context/` directly; collect just automates the find-and-copy step.

Collect is deliberately non-autonomous: the agent surveys directories but does not decide what is relevant. That judgment belongs to the user.

## Protocol

1. **Ask for source directories.** "Which directories should I survey for potentially relevant files? List paths (absolute or relative to project root). I'll show you what's there — you select what to import."

2. **Survey each directory.** Using `find`, list all files in the specified directories (non-recursive by default; ask "include subdirectories?" if the user hasn't specified). Show the list as a numbered inventory:
   ```
   [1]  path/to/file.pdf         (42 KB)
   [2]  path/to/draft.docx       (18 KB)
   [3]  path/to/notes.md         (3 KB)
   ...
   ```
   Do not read file contents at this stage. Do not filter or pre-judge relevance.

3. **Ask the user to select.** "Which of these should I import to `context/`? Reply with numbers (e.g. '1, 3, 5'), a range ('1-5'), or 'all'. You can also say 'none' to cancel."

   If the list is long (>15 files), offer: "Want me to describe any of these files before you choose? Give me numbers and I'll peek at each one."

4. **For description requests:** Read only the requested files (briefly — first ~30 lines or equivalent) and provide a one-line description of each. Then re-ask for selection.

5. **Copy selected files to `context/`.** For each selected file:
   - Destination filename: `YYYY-MM-DD_[original-filename].[ext]` (today's date)
   - If a file with the same name already exists in `context/`, append `-2`, `-3`, etc.
   - Copy the file (do not move; the original stays in place)

6. **Update `context/README.md`.** Append one row per imported file to the import log table:
   ```
   | YYYY-MM-DD | /original/path/filename.ext | YYYY-MM-DD_filename.ext | <one-line description if known, else "imported via /spec collect"> |
   ```

7. **Report back.** "Imported N file(s) to `context/`. Run `/spec extract` to process them."

## Notes

- Collect never reads file contents without the user explicitly requesting it (step 4 descriptions).
- Collect never decides what is relevant — that is the user's call at step 3.
- Files in `context/` are frozen inputs. If you need a modified version, create it in `deliverables/` instead.
