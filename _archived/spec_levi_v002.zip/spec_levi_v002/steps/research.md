# /spec research — Web-enabled external fact-finding

Strategic, question-driven web research. Produces a cited research report tagged `[from-research]`. Requires citations — uncited claims go to Unconfirmed, not Findings.

## State machine

**Allowed from phases:** `interviewing` · `seeded` · `in-review` · `revised`
**Transitions to:** same phase (no phase change)
**Re-run behavior:** Allowed. Each run produces a new archive file. `latest_research` in state.yaml always points to the most recent. Multiple research runs per iteration are normal (e.g., one pre-seed for grant requirements, one during review to answer a persona challenge).

Read state.yaml first; validate phase. Write state.yaml on completion.

## What research is for

Research is *targeted*: it answers specific factual questions that the interview or review surfaces. It is not ambient browsing. Every research run starts with explicit questions — the agent does not decide what to investigate.

Common triggers:
- Grant or application requirements (e.g., "what does VIPC require in the executive summary?")
- Market size or competitive landscape data
- Technical constraints (file formats, submission systems, deadlines)
- Regulatory or compliance facts
- Pricing, availability, or API behavior of external tools

Key trust principle: **`[from-research]` findings require citations.** A finding without a verifiable URL or source is not a research finding — it is speculation and goes in Unconfirmed. The seed step treats uncited items as `## Open questions` in `spec/spec.md`, not as facts.

Distinction from related commands:
- **`/spec extract`** — local docs only, no web access.
- **`/spec explore`** — local synthesis only, no web access.
- **`/spec research`** — web-enabled, targeted questions, citations required.

## Protocol

1. **Collect research questions.** Ask: "What specific questions need external answers? List them — each will be researched individually." If the user provides URLs to check, note them. Decline vague mandates like "research the market" — ask for a specific question instead (e.g., "What is the estimated TAM for [product category] in 2025?").

2. **Confirm question list.** Present the questions back and ask: "Anything to add or remove before I start?"

3. **Search plan confirmation (required).** Before spawning the sub-agent, the main session agent (you, not a sub-agent) proposes a search plan for each question:
   - What search query you would use
   - What type of source would best answer it (official docs, news, academic, registry, etc.)
   - Any user-provided URLs to check first

   Present this plan and ask: "Does this search strategy look right? If any questions should use a specific source or URL, say so now. I won't go beyond this plan without asking."

   Adjust the plan based on user feedback before proceeding. This is the autonomy gate — the sub-agent will be constrained to the approved plan.

4. **Spawn general-purpose sub-agent.** Use `subagent_type: "general-purpose"` and `model: "sonnet"` — general-purpose is required here because it has WebSearch and WebFetch access. The prompt must include the **write-fallback instruction from SKILL.md principle 7**. Prompt:

   > You are performing targeted web research to answer specific questions for a spec-development process. Your mandate: answer each question as precisely as possible, cite every source, and be explicit about what you could not confirm. Do not speculate beyond what sources support.
   >
   > Research questions:
   > `<numbered list of user-provided questions>`
   >
   > User-provided URLs to check (if any): `<list, or "none">`
   >
   > Produce the file at `<absolute path: spec/archive/v<NNN>-YYYY-MM-DD-HHMM-research.md>` with these sections:
   >
   > ## Research report — `[from-research]` — citations required
   > *Every factual claim must be paired with a source URL. Uncited claims go under Unconfirmed, not Findings.*
   >
   > ### Research questions
   > List the questions verbatim, as provided.
   >
   > ### Findings
   > One subsection per question. For each:
   > - Your answer, as specifically as possible
   > - Source URL(s) inline after each claim: `(source: https://...)`
   > - Confidence: **High** (directly stated in source) / **Medium** (inferred from source) / **Low** (indirect or conflicting sources)
   >
   > ### Unconfirmed
   > Questions where you could not find reliable sourced answers. State what you found and why it doesn't meet the citation bar. Do not include unsourced answers in Findings.
   >
   > ### Source log
   > Full list of URLs accessed, with one-line description of what each contained.
   >
   > If a question requires a judgment call rather than a fact, say so explicitly and put it in Unconfirmed.
   >
   > Attempt the Write tool for the target path. If denied, retry once; if still denied, include the full intended file content verbatim in your final reply inside a fenced code block labeled with the target absolute path, so the parent session can write it. Never report success without either having written the file or having dumped its full content.

   Also pass the approved search plan as a constraint: "Approved search strategy: `<summary of plan from step 3>`. Do not search for sources or visit URLs outside this scope without noting them explicitly in the Source log with a reason."

5. **Verify the file exists.** After the sub-agent returns, check whether the archive file was written. If not, write it from the dumped content.

6. **Present summary.** Report how many questions were answered at each confidence level, and how many are unconfirmed. Tell the user:
   > "Review `spec/archive/<filename>`. High- and medium-confidence findings with citations may be used as `[from-research]` facts in the spec. Unconfirmed items will surface as `## Open questions` in `spec/spec.md` — they don't block seeding but flag what still needs a human answer."

7. **Update state.yaml:** `latest_research: <archive filename>`, `last_command: /spec research`, `last_command_at: <timestamp>`. Phase unchanged.

8. **Propose commit:**
   ```
   git add spec/archive/<filename> spec/state.yaml
   git commit -m "spec: research v<n>"
   ```
