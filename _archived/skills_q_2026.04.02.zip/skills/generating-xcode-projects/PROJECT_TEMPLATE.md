# Project Configuration Template

Complete reference for creating `project.yml` files for XcodeGen.

## Basic iOS App Template

```yaml
name: <ProjectName>
options:
  bundleIdPrefix: com.<organization>
  deploymentTarget:
    iOS: 17.0
settings:
  DEVELOPMENT_TEAM: <TeamID>
targets:
  <ProjectName>:
    type: application
    platform: iOS
    sources:
      - <SourceDirectory>
    settings:
      GENERATE_INFOPLIST_FILE: YES
      INFOPLIST_KEY_CFBundleDisplayName: <AppName>
      INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents: YES
      INFOPLIST_KEY_UISupportedInterfaceOrientations:
        - UIInterfaceOrientationPortrait
        - UIInterfaceOrientationLandscapeLeft
        - UIInterfaceOrientationLandscapeRight
      INFOPLIST_KEY_UISupportedInterfaceOrientations_iPad:
        - UIInterfaceOrientationPortrait
        - UIInterfaceOrientationPortraitUpsideDown
        - UIInterfaceOrientationLandscapeLeft
        - UIInterfaceOrientationLandscapeRight
      ENABLE_PREVIEWS: YES
      SWIFT_VERSION: 5.0
      TARGETED_DEVICE_FAMILY: 1,2
```

## macOS App Template

```yaml
name: <ProjectName>
options:
  bundleIdPrefix: com.<organization>
  deploymentTarget:
    macOS: 13.0
settings:
  DEVELOPMENT_TEAM: <TeamID>
targets:
  <ProjectName>:
    type: application
    platform: macOS
    sources:
      - <SourceDirectory>
    settings:
      GENERATE_INFOPLIST_FILE: YES
      INFOPLIST_KEY_CFBundleDisplayName: <AppName>
      INFOPLIST_KEY_NSPrincipalClass: NSApplication
      ENABLE_PREVIEWS: YES
      SWIFT_VERSION: 5.0
```

## Project with Tests

```yaml
name: <ProjectName>
options:
  bundleIdPrefix: com.<organization>
  deploymentTarget:
    iOS: 17.0
settings:
  DEVELOPMENT_TEAM: <TeamID>
targets:
  <ProjectName>:
    type: application
    platform: iOS
    sources:
      - <SourceDirectory>
    settings:
      GENERATE_INFOPLIST_FILE: YES
      INFOPLIST_KEY_CFBundleDisplayName: <AppName>
      ENABLE_PREVIEWS: YES
      SWIFT_VERSION: 5.0

  <ProjectName>Tests:
    type: bundle.unit-test
    platform: iOS
    sources:
      - <TestsDirectory>
    dependencies:
      - target: <ProjectName>
    settings:
      GENERATE_INFOPLIST_FILE: YES
      SWIFT_VERSION: 5.0
```

## Common Info.plist Keys

Replace physical Info.plist entries with build settings:

| Info.plist Key | Build Setting Key |
|----------------|-------------------|
| `CFBundleDisplayName` | `INFOPLIST_KEY_CFBundleDisplayName` |
| `LSApplicationCategoryType` | `INFOPLIST_KEY_LSApplicationCategoryType` |
| `UIApplicationSupportsIndirectInputEvents` | `INFOPLIST_KEY_UIApplicationSupportsIndirectInputEvents` |
| `UISupportedInterfaceOrientations` | `INFOPLIST_KEY_UISupportedInterfaceOrientations` |
| `NSCameraUsageDescription` | `INFOPLIST_KEY_NSCameraUsageDescription` |
| `NSLocationWhenInUseUsageDescription` | `INFOPLIST_KEY_NSLocationWhenInUseUsageDescription` |
| `NSPhotoLibraryUsageDescription` | `INFOPLIST_KEY_NSPhotoLibraryUsageDescription` |

## App with Entitlements

```yaml
targets:
  <ProjectName>:
    type: application
    platform: iOS
    sources:
      - <SourceDirectory>
    settings:
      GENERATE_INFOPLIST_FILE: YES
      CODE_SIGN_ENTITLEMENTS: <SourceDirectory>/<ProjectName>.entitlements
      ENABLE_PREVIEWS: YES
```

Ensure the `.entitlements` file exists at the specified path.

## App with SwiftData

```yaml
targets:
  <ProjectName>:
    type: application
    platform: iOS
    sources:
      - <SourceDirectory>
    settings:
      GENERATE_INFOPLIST_FILE: YES
      ENABLE_PREVIEWS: YES
      SWIFT_VERSION: 5.0
```

SwiftData requires no special configuration - just include your model files in sources.

## Multi-platform App

```yaml
name: <ProjectName>
options:
  bundleIdPrefix: com.<organization>
  deploymentTarget:
    iOS: 17.0
    macOS: 13.0
targets:
  <ProjectName>-iOS:
    type: application
    platform: iOS
    sources:
      - Sources/Shared
      - Sources/iOS
    settings:
      PRODUCT_BUNDLE_IDENTIFIER: com.<organization>.<projectname>
      GENERATE_INFOPLIST_FILE: YES
      ENABLE_PREVIEWS: YES

  <ProjectName>-macOS:
    type: application
    platform: macOS
    sources:
      - Sources/Shared
      - Sources/macOS
    settings:
      PRODUCT_BUNDLE_IDENTIFIER: com.<organization>.<projectname>
      GENERATE_INFOPLIST_FILE: YES
      ENABLE_PREVIEWS: YES
```

## Build Settings Reference

**Code Signing:**
```yaml
settings:
  DEVELOPMENT_TEAM: <TeamID>
  CODE_SIGN_STYLE: Automatic
  CODE_SIGN_ENTITLEMENTS: <Path>
```

**Swift Configuration:**
```yaml
settings:
  SWIFT_VERSION: 5.0
  SWIFT_OPTIMIZATION_LEVEL: -Onone  # Debug
  SWIFT_COMPILATION_MODE: wholemodule  # Release
```

**Deployment:**
```yaml
settings:
  IPHONEOS_DEPLOYMENT_TARGET: 17.6
  TARGETED_DEVICE_FAMILY: 1,2  # iPhone and iPad
```

**SwiftUI:**
```yaml
settings:
  ENABLE_PREVIEWS: YES
```

## Placeholders to Replace

When using these templates, replace:
- `<ProjectName>`: Your project name (e.g., "MyApp")
- `<AppName>`: Display name shown to users
- `<organization>`: Organization identifier (e.g., "yourcompany")
- `<TeamID>`: Apple Developer Team ID (10-character code)
- `<SourceDirectory>`: Source code directory (e.g., "Sources", "MyApp")
- `<TestsDirectory>`: Test files directory (e.g., "Tests", "MyAppTests")

## Project Structure Example

```
MyApp/
├── project.yml
├── Sources/
│   ├── MyAppApp.swift
│   ├── Views/
│   ├── Models/
│   └── ViewModels/
├── Tests/
│   └── MyAppTests.swift
└── MyApp.xcodeproj/  (generated by XcodeGen)
```
