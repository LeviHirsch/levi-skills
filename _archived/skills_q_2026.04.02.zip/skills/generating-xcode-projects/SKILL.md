---
name: generating-xcode-projects
description: Generates Xcode project files (.xcodeproj) using XcodeGen from Swift source code. Use when the user asks to create an Xcode project, generate a .xcodeproj file, or set up an iOS/macOS app project structure.
---

# Generating Xcode Projects

Automatically generate `.xcodeproj` files from Swift source code using XcodeGen.

## Prerequisites

Check if XcodeGen is installed:
```bash
which xcodegen || brew install xcodegen
```

If Homebrew is not available, inform the user that XcodeGen is required and provide installation instructions.

## Workflow

Copy this checklist and track progress:

```
Project Generation Progress:
- [ ] Step 1: Complete all Swift source file generation
- [ ] Step 2: Create project.yml configuration
- [ ] Step 3: Generate .xcodeproj with XcodeGen
- [ ] Step 4: Validate project configuration
- [ ] Step 5: Test build
```

### Step 1: Complete all Swift source file generation

Ensure all Swift files, assets, and resources are generated before creating the Xcode project.

### Step 2: Create project.yml configuration

Generate `project.yml` in the project root directory using the template from [PROJECT_TEMPLATE.md](PROJECT_TEMPLATE.md).

**Critical configuration rules to prevent Info.plist conflicts:**
- Set `GENERATE_INFOPLIST_FILE: YES` in target settings
- **NEVER** add `INFOPLIST_FILE` setting
- **NEVER** create a physical `Info.plist` file
- Use `INFOPLIST_KEY_*` settings for all Info.plist values

### Step 3: Generate .xcodeproj with XcodeGen

Run XcodeGen:
```bash
xcodegen generate
```

This creates the `.xcodeproj` from your `project.yml` specification.

### Step 4: Validate project configuration

Run the validation script:
```bash
bash scripts/validate_project.sh
```

This checks for common configuration issues like Info.plist conflicts.

### Step 5: Test build

Build the project to verify it works:
```bash
xcodebuild -project <ProjectName>.xcodeproj \
  -scheme <SchemeName> \
  -destination 'platform=iOS Simulator,name=iPhone 15' \
  clean build
```

If the build succeeds, inform the user that the project is ready:
```
✅ Xcode project generated successfully!
Open with: open <ProjectName>.xcodeproj
```

## Common project types

**iOS App:**
- Platform: iOS
- Type: application
- Deployment target: iOS 17.0+
- Framework: SwiftUI or UIKit

**macOS App:**
- Platform: macOS
- Type: application
- Deployment target: macOS 13.0+
- Framework: SwiftUI or AppKit

**Framework/Library:**
- Type: framework
- Include unit test target

## Configuration reference

See [PROJECT_TEMPLATE.md](PROJECT_TEMPLATE.md) for:
- Complete project.yml template with all common settings
- Target configuration examples
- Build settings reference
- Multi-target project structures

## Troubleshooting

**"Command not found: xcodegen"**
- XcodeGen is not installed
- Provide installation instructions: `brew install xcodegen`

**Build fails with Info.plist errors**
- Run `bash scripts/validate_project.sh`
- Check that `GENERATE_INFOPLIST_FILE: YES` is set
- Verify no `INFOPLIST_FILE` setting exists
- Remove any physical Info.plist files

**Missing source files in project**
- Verify all source directories are listed in `sources` array
- Check file paths are relative to project root
- Re-run `xcodegen generate`
