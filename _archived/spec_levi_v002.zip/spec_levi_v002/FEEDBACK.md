# Spec Skill Feedback

Feedback and notes compiled for the skill author. Updated as new observations arise.

---

## Feedback & Suggestions

### UX / Onboarding

- **Missing entry-point command:** When first encountering the skill, it wasn't obvious how to get started. A `/spec start` or `/spec setup` command would give new users a clear on-ramp — something that walks through initial setup or explains what the skill expects before diving into subcommands like `/spec interview`.
- **No explicit directory setup protocol:** There is no dedicated step or command for initializing the `spec/` and `spec/archive/` directories before the first run. The SKILL.md notes "create on first use," but this is implicit — a `/spec setup` or initialization protocol that explicitly creates the required directory structure (and optionally explains each artifact) would reduce confusion for new users about what state the project should be in before `/spec interview`.
- **No convention for context/reference documents:** There is no guidance on where to put documents that inform the project but aren't spec artifacts — e.g., source of truth references, existing designs, stakeholder briefs, or domain constraints. The skill doesn't distinguish between "guiding context" (informational, user-owned) and "spec artifacts" (skill-managed). A `spec/context/` convention or a "context drop" step in setup would give users a clear home for these resources and a way for the interview step to pull from them explicitly.
- **Git requirement is too strong for non-code projects:** The bare `/spec` state-detection response lists git init as a required setup step. For document-only or non-software projects (e.g., a form design workflow), git feels like unnecessary overhead. The skill should clarify that git is optional — commits are proposed but never run — and that `spec_sha` will simply be `null` without it. The setup advice should be softer: "git is useful but not required."

### Permissions / Runtime Behavior

- **Subskill file reads require per-call approval:** Even after `/spec` is invoked (injecting the main skill content), each read of a sub-step file (e.g. `steps/feedback.md`, `steps/adopt.md`) triggers a separate `Read` tool permission prompt. The skill's invocation doesn't grant blanket approval for runtime reads. Workaround: allowlist `~/.claude/skills/spec/**` in Claude Code settings. The skill's README or onboarding should mention this and suggest the allowlist fix.

### Interview / Interaction Pacing

- **Multiple ambiguities presented at once:** During the interview phase, the skill surfaced 3 ambiguities to resolve simultaneously. One at a time would feel less cognitively loaded and more in the spirit of a Socratic dialogue. A configurable or default "one question at a time" cadence for ambiguity resolution would be preferable, with a bulk-mode opt-in for users who want to move faster.

### Command Interface

- **Parameter passing in `/` parsing:** It's unclear whether parameters could be made more explicit by parsing them directly from the slash command (e.g. `/spec implement feature-name`). If the harness supports argument extraction at parse time, surfacing those parameters explicitly would make invocations feel more intentional and self-documenting. Worth investigating feasibility.
- **Claude widget / structured input for disambiguation:** The Claude Code UI supports a widget-style interaction model (tabbed/segmented choices, multiple-choice prompts). Using this for things like ambiguity resolution or clarity-gate scoring could make those interactions feel more deliberate and reduce the friction of free-text responses. Worth investigating whether skills can trigger the widget API.

### Non-Software Project Types & Constrained-Criteria Use Cases

- **Skill is implicitly scoped to software projects:** The language throughout (implementation phases, acceptance criteria, code adoption) assumes a software delivery context. The skill's core workflow — interview → spec → review → verify → close — is actually well-suited to a broader class of projects, and two in particular seem like natural fits:
  - **Constrained-criteria projects** (job applications, grant applications, RFP responses): The target artifact is defined by an external rubric or form. The "spec" is essentially a mapping of the user's strengths/content to the required criteria. The interview phase could surface gaps; the review personas could stress-test the fit; verify could cross-check against the original criteria document. The key difference: the acceptance criteria are largely given, not invented.
  - **Deliverable-oriented projects** (business plans, research proposals, pitch decks): There's a known artifact type with conventional structure, but the content is user-generated. Similar to greenfield software but the "implementation phases" are document sections, not code modules.
- **What would need to change:** Interview framing and seed templates are the main levers. The state machine and persona review structure likely carry over as-is. A `project_type` setting (see Skill-Level Settings section) could select the right interview script and seed template without requiring a full fork of the skill.
- **Real example:** Used the skill to produce a full system-prompt / instructions document intended to be pasted into Claude in Chrome to guide editing a Google Form. The deliverable here was a *prompt artifact*, not code — yet the workflow mapped reasonably well. This suggests the skill is already more general than its framing implies, but the language and verify step would need to adapt (verifying a prompt document against intent criteria is different from auditing code against ACs).

### Skill-Level User & Project Settings

- **No per-user or per-project preference layer:** The skill has no mechanism for storing behavioral preferences — everything is hardcoded in the skill logic. A lightweight settings layer (e.g. `~/.claude/skills/spec/user-prefs.yaml` for user-global, or `spec/settings.yaml` for project-level) could allow meaningful customization without forking the skill. Candidate settings:
  - **Project type** — e.g. `software`, `deliverable`, `learning`, `process` — which could adjust the interview framing, AC structure, and persona emphasis.
  - **Interaction chunking** — e.g. `one-at-a-time` vs `batched` for ambiguity resolution, clarity-gate questions, and persona critiques.
  - **Socratic depth** — how many follow-up questions before moving to seed; could be user-tunable.
  - **Commit behavior** — whether to propose git commits at all (relevant for non-code projects).
- **Project-level settings seem feasible today:** A `spec/settings.yaml` checked into the repo could serve as project-scoped prefs, read at the start of each step. User-global prefs would require a convention outside the project directory (e.g. `~/.claude/skills/spec/prefs.yaml`). The skill could read both and merge, with project taking precedence.

---

## Local Adjustments

Changes made to this local copy of the skill. Useful for diffing against upstream and reporting back to the author.

| Adj | Date | File | Change | Reason |
|-----|------|------|--------|--------|
| #1 | 2026-04-27 | `FEEDBACK.md` | Created file with skeleton (Feedback & Suggestions, Local Adjustments, Open Questions, Resolved sections) | Needed a persistent place to compile feedback for the skill author |
| #1 | 2026-04-27 | `steps/feedback.md` | Created new step file defining the `/spec feedback` command | Allows feedback to be logged from within the skill itself |
| #1 | 2026-04-27 | `SKILL.md` | Added `/spec feedback` to routing table and description frontmatter | Wires the new command into the skill's dispatch logic |
| #2 | 2026-04-29 | `steps/collect.md` | Created new step file for `/spec collect` | Provides a curated file-import protocol for `context/` — distinct from explore (logistics vs. synthesis). Collect presents a candidate list; user selects; agent copies with timestamp naming. No sub-agent needed; main agent uses `find`. Never pre-judges relevance. |
| #2 | 2026-04-29 | `steps/extract.md` | Created new step file for `/spec extract` | Constrained fact-extraction pass over `context/` files only. Produces four-section quarantine (Established / Verify / Flagged / Discarded). Sub-agent has no synthesis mandate. User reviews before seeding. |
| #2 | 2026-04-29 | `steps/explore.md` | Created new step file for `/spec explore` | Interpretive synthesis over user-specified local files. Advisory output tagged `[from-explore]`. Scope constraint added to sub-agent prompt: no files outside specified paths, no web requests. |
| #2 | 2026-04-29 | `steps/research.md` | Created new step file for `/spec research` | Web-enabled targeted fact-finding. Citations required. Key design decision: main session agent proposes and user approves a search plan BEFORE the sub-agent runs — this is the autonomy gate. Sub-agent receives approved plan as a constraint. |
| #2 | 2026-04-29 | `SKILL.md` | Added collect/extract/explore/research to routing table, state.yaml schema (latest_extract, latest_explore, latest_research), and file layout | Wires four new commands into the skill |
| #2 | 2026-04-29 | `steps/seed.md` | Added check for latest_extract/explore/research in prerequisites; added context input trust hierarchy to sub-agent prompt | Seed now reads all three context files if they exist; tags ACs with origin; uncited research items become Open questions |
| #2 | 2026-04-29 | `steps/interview.md` | Added step 1a to both greenfield and iteration protocols | Pre-interview silent read of extract/explore/research files; findings inform questions, not answers; claims tagged in session file |

---

## Open Questions

- Can the harness extract slash command arguments at parse time to support richer parameter syntax?

---

## Resolved / Reported

Items that have been sent to the author or are no longer relevant.

_(none yet)_
