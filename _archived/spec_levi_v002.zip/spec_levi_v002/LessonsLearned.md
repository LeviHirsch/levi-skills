# Lessons Learned — Spec Skill in Practice

## Case: haptic-fellowship-feedback-form (2026-04-27/28)

**Use case type:** Document revision (Google Form, brownfield adopted mode)
**Iteration:** 1, adopted, closed PASS-WITH-ACCEPTED-GAPS

---

## What worked well

- **`[adopted]` / `[delta]` AC tagging** was exactly right for document revision — distinguishing "what the draft already does" from "what this iteration adds" was the most intellectually useful structure in the whole spec.
- **Phased approach** (structure → content → polish/audit) mapped cleanly onto document editing without modification. Three phases was the right count; merging new-question authoring and existing-question revision into a single Phase 2 was the correct call.
- **`decisions.log`** captured alternatives and rationale that would otherwise be lost. The takeaway distilled it well.
- **Open questions in the spec** provided a clean place to defer decisions to implementation time without blocking convergence.
- **The brownfield `[adopted]` invariants pattern** surfaced one real gap: a specific proper noun (the stipend model) that existed in the invariants and ACs but had no corresponding question in the source document. A post-verify addition resolved it. This pattern — adopted references that don't exist yet in any question — is a verify-time risk worth calling out explicitly in the verify step for brownfield-originated documents.

---

## Where the skill created friction

### 1. "From-code" is the wrong tag for document projects
The adopt and verify steps use `[from-code]` throughout. Here the "source" was a markdown draft, not code. Language like "scan the codebase," "file:line refs in the codebase," and "shipped reality [from-code]" required mental translation throughout.

**Fix:** `[from-code]` → `[from-source]` everywhere. "codebase" → "source material." The Explore sub-agent prompt for adopt should replace "architecture, entry points, public surface, data model" with "structure, key claims, constraints, invariants, and tensions between source documents."

### 2. Git assumed everywhere, no graceful degradation
Every step proposed `git add` / `git commit`. This project lived in iCloud with no git repo. Commit proposals were noise at every turn.

**Fix:** At the start of any step that proposes a commit, check `git rev-parse --git-dir`. If it fails, substitute "save a backup copy of `spec/`" instead.

### 3. "Implementation" means something different for document projects
The implement step is designed to kick off code writing in a fresh session and audit file:line changes. Here, implementation meant producing editing instruction sets for a separate Claude session to apply to a Google Form UI. The kickoff prompt language ("write code," "implementation files") had to be mentally translated.

**Fix:** The implement step's kickoff prompt template should use "produce the deliverable" / "output artifact" rather than code-specific language. The artifact type is inferred from context, not hardcoded.

### 4. Verify couldn't use file:line refs the way it expected
Verification was designed to grep a codebase. Here it had to read a markdown file (the revised form draft) and match content claims to line numbers in that document. Workable, but awkward.

**Fix:** Same as #1 — decoding the language makes this feel natural rather than forced.

### 5. One source document assumed
The adopt step's Q1 asks for one rough spec path. Document projects often involve multiple source files (existing pitch deck, business plan, prior draft, etc.).

**Fix:** Q1 becomes "Path(s) to source documents — space-separated for multiple, or `none`." The Explore sub-agent reads each.

---

## Proposed generalizations

### Tier 1 — Surgical, high-leverage (language decoding)

1. `[from-code]` → `[from-source]` across SKILL.md, adopt.md, verify.md, takeaway template
2. "codebase" → "source material" / "project" throughout
3. "write code" → "produce deliverable" in implement.md kickoff prompt
4. "software project" → "project or deliverable" in SKILL.md description
5. No-git graceful degradation: check for git before proposing commit commands

### Tier 2 — Grant submission and multi-document use cases

**Field-constraint AC syntax.** Add a tagging convention for ACs with hard constraints: `[max: 500 chars]`, `[required-topics: mission, impact]`, `[vocabulary: funder-name]`. The verify step checks these mechanically.

**Multi-source document support.** The adopt step should accept multiple source paths; the Explore sub-agent synthesizes across all of them.

**Multi-artifact output tracking.** Optional `deliverables:` list in state.yaml when a single iteration produces multiple output artifacts (e.g., grant form fields + adjusted pitch deck + adjusted exec summary).

**Scope annotation.** Optional `scope: delivery | development` in state.yaml. When `delivery`, the skill surfaces the deadline in the clarity gate, biases toward faster convergence, and notes the delivery scope in the takeaway. Useful for grant submissions (narrow delivery window) vs. iterative product development.

---

## Grant submission use case — structural notes

| Dimension | Grant submission |
|---|---|
| Source material | Multiple docs (pitch deck, exec summary, business plan) |
| Output | Form fields + adjusted supplementary docs |
| Constraints | Character limits, required topics, funder vocabulary |
| Verification | Field-by-field content check |
| Timeline | Narrow delivery window tied to deadline |
| Git | Rarely |

The grant use case has one feature the current skill doesn't model: **each output artifact has field-level constraints** (field X: 500 chars, must address impact and sustainability; field Y: 250 chars, must name program officer). These are testable ACs but not the kind the current spec template is shaped for. The field-constraint AC syntax proposal (Tier 2) addresses this directly.

---

## Recommendation

Start with Tier 1. De-coding the language is mostly a find/replace across the skill files, costs almost nothing, and makes every non-software use feel native rather than translated. No-git degradation removes the most visible friction. Together they would have eliminated the majority of friction in this project without any behavioral change to the skill's logic.
