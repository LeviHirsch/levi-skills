# Deferred items

_Backlog of feature requests, bug reports, and ideas not yet committed to any iteration. Triaged at each iteration's interview._

## D-001 — `navigateToConversation` dedup drops different-conversation push taps
- First seen: 2026-05-01 (iteration 8, via /spec reconcile bucket: defer)
- Last touched: 2026-05-01 (iteration 8)
- Defer count: 0
- Category: bug
- Description: `AppCoordinator.navigateToConversation` deduplicates push-tap navigation by checking `nav.topViewController is ChatViewController`. If a `ChatViewController` is already at the top, the push is skipped entirely — even when the tap targets a *different* conversation. The dedup logic does not compare `conversationId`. (`Haptic/App/AppCoordinator.swift:305–306`)
- Notes: Latent in iteration 8 because foreground push notifications are suppressed (AC1.9). The bug only triggers on a background-tap → another-background-tap-for-different-conversation sequence with the user landing in a different `ChatViewController` between taps. Recoverable by re-tapping the second notification once the user navigates away. Fix in a future iteration: compare `conversationId` before dedup-skipping, or pop and push when the top view's conversation differs from the tapped one.

## D-002 — Remove `messages.expires_at` column and iOS `expiresAt` field
- First seen: 2026-05-01 (iteration 8, via /spec reconcile post-recovery follow-up)
- Last touched: 2026-05-01 (iteration 8)
- Defer count: 0
- Category: refactor
- Description: After DEC-079 (migration recovery), `messages.expires_at` lingers as dead metadata: the iOS client writes a `now() + 90 days` value at every message insert (5 call sites in `ChatViewModel`, plus `MessageDTO`, `LocalMessage` SwiftData model, `Message` Domain entity), but no consumer reads it (the cleanup function that depended on it was removed in iteration 8 to honor the spec's "indefinite retention" constraint). Goal: drop the column from the DB schema and remove `expiresAt` from the iOS layer end-to-end.
- Notes: This is the Option C end state from the iteration-8 reconcile dialogue — deferred to iteration 9 to avoid bundling a non-trivial Domain/DTO/SwiftData refactor under iteration-8's submission deadline. Touch points: `Message.swift` (Domain), `MessageDTO.swift` (Data/Remote/DTOs), `LocalMessage.swift` (SwiftData `@Model` — needs lightweight migration or store-reset, since removing a non-optional `@Model` property is not free), `ChatViewModel.swift` (5 call sites at lines ~439, 497, 627, 808, 841 as of iteration-8 close), `SendHapticMessageUseCase`, `SendTextMessageUseCase`, plus tests under `HapticKit/Tests/`. New SQL migration to `ALTER TABLE messages DROP COLUMN expires_at` lands after the iOS-side change merges (so writes stop before the column disappears).
