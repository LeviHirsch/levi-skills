# Haptic App — Specification (iteration 8)

> Status: draft
> Revision: 3
> Prior iteration: `spec/archive/v007-2026-04-27-0813-verify.md` (closed 2026-04-27 at SHA `8e86d37`)
> Last updated: 2026-04-27

## Goal

Make the Haptic iOS app submission-ready for Apple's External Beta Review by tomorrow evening: ship push notifications, an in-app bug-report flow, refreshed visual identity (new dark glassmorphic theme + matching logo + retire/merge older themes), Beta-readiness compliance (Privacy/Terms hosting, profile-name UX, secret-leak sanity check, beta-surface sweep), a partial invite-link reusability fix, and a cross-repo update consistentizing site copy with app reality; plus close two known UX-precondition issues (realtime-tap edge case and NetworkMonitor discard-on-loss) before opening the external-beta gate, and build an external app-review-artifact pipeline.

## Motivation

Iteration 7 was the adoption pass — it produced the first ratified spec and verified baseline with no code changes. Iteration 8 is the first code-change iteration: it targets Beta App Review external submission (2026-04-28 evening) and fires several iteration-7 `[iteration-scope]` deferrals (`SettingsViewModel` extraction, theme catalog changes) alongside new Beta-readiness workstreams (Privacy/Terms, push notifications, bug-report flow, App Icon, data-collection summary, secret-leak audit). The target date compresses roughly two weeks of normal-speed work to ~36 hours using agentic implementation velocity.

**Why this bundle, and why now:** Beta App Review exists specifically to open the app to *external* beta testers. Two consequences shape scope. First, Apple's review pipeline takes time, so any feature gap that would force a second round of review is more expensive than packing it in now — push notifications, the new theme + theme migration, and the in-app bug-report flow are the minimum feature set external beta testers need, so they ship together rather than across two review cycles. Second, two known UX issues are in scope as **preconditions for opening the gate**, applied consistently: AC14 (realtime-tap edge case, ~30% repro rate) and AC15 (NetworkMonitor discard-on-loss, behaviorally unverified). Passing Apple's review while either issue is live would still mean a broken or data-incoherent experience for external testers on day one. The earlier draft re-deferred NetworkMonitor on the basis that it isn't on the submission critical path — but that argument applies equally to AC14, which we kept; the consistent rule is "don't open the gate on a known broken experience," and both issues now live under that rule.

## Current state `[from-code]`

All details from iteration 7's verified baseline. Key touchpoints for this iteration:

- **Settings (at iteration-8 close):** `SettingsView` is SwiftUI; consumes `SettingsViewModel` (`@Observable`, `@Bindable`) and observes `ThemeProvider.shared` via `@ObservedObject` for theme switching. Settings sections: profile-name editor, notifications status, theme picker, bug-report entry, account (Sign Out). The former `debugSection` (NavigationLink → `RealtimeLogView`) is now `#if DEBUG`-gated per DEC-065; `RealtimeLogView` / `RealtimeLogStore` source files were removed in iteration 8 (departure from the lies-dormant convention — `rtLog` reroutes to OSLog + DEBUG `print`). (`haptic/Presentation/Settings/SettingsView.swift`)
- **Theme system (at iteration-8 close):** Three concrete themes registered: `DeepBloomTheme`, `PulseTheme`, `ArcadeTheme`. `BrutalistTheme` and `BioluminescentTheme` source files retained dormant under `Presentation/Theme/Dormant/` and excluded from the build target (their `ThemeID` cases were removed; the dormant files do not compile if re-included). `ThemeProvider` is `ObservableObject + @Published + NotificationCenter`; persists to `UserDefaults`; broadcasts `themeDidChangeNotification`. (`haptic/Presentation/Theme/ThemeProvider.swift`)
- **Auth screen:** `AuthViewController` is a pure `UIHostingController<AuthView>` with no UIKit logic. `AuthViewModel` is `@MainActor @Observable`. (`haptic/Presentation/Auth/`)
- **Invite handling:** `AppCoordinator` contains `resolvingInviteCodes: Set<String>` for client-side dedup; server/DB currently invalidates invite links after first use. (`haptic/App/AppCoordinator.swift`)
- **Backend:** 8 migration files through 2026-03-12; RLS on all 6 tables; no push-notification infrastructure or APNs integration exists yet. (`supabase/migrations/`)
- **App Icon:** `Assets.xcassets/AppIcon` contains current icon set; source logo asset exists. No `setAlternateIconName` usage.
- **NetworkMonitor:** `ChatViewModel` gates tap recording behind `isNetworkAvailable` and discards in-progress sessions on mid-tap network loss. The code path exists; behavioral verification is in scope for this iteration (AC15). (`haptic/Infrastructure/NetworkMonitor.swift`, `haptic/Presentation/Chat/ChatViewModel.swift`)

## Change delta

### Added

- Server-triggered push notifications: Supabase Edge Function fires on `messages` table insert → APNs → iOS. iOS registers for push on sign-in (`UNUserNotificationCenter` + APNs registration). New `PushNotificationService` / `PushNotificationRepository` (separate from `SupabaseRealtimeRepository`).
- `SettingsViewModel` extracted from `SettingsView` (iteration-7 deferral fires): `ObservableObject + @Published`; owns profile-name editing logic (validation, trim, persistence feedback). `SettingsView` becomes a View layer again.
- Profile-name editor in Settings: text field to confirm or change the in-app display name sourced from Sign in with Apple; routes through `UpdateProfileUseCase` → `UserRepository` → Supabase `profiles` table.
- Browse-wrap legal notice on sign-in screen with tappable links to Privacy Policy and Terms of Service (URLs hosted at `tryhaptic.com`).
- In-app bug-report flow in Settings (no shake-to-report): user manually describes bug; device metadata appended; destination architecture selected after web-research AC (minimize 3rd-party vendors; GitHub Issues acceptable; human review gate before issuification).
- New dark third theme (`PulseTheme`, coal-on-graphite palette with ember-orange accents — see DEC-055; the original "dark glassmorphic" framing was dropped during implementation): new `HapticTheme` implementation registered in `ThemeProvider`.
- New logo: replaces in-app brand asset AND `Assets.xcassets/AppIcon` (1024×1024 + required size variants). No per-theme alternate App Icons.
- `migrateLegacyThemeKeys()` step in `ThemeProvider.init()`: catch-all migration — any persisted `UserDefaults` theme key not in `ThemeID.allCases` is silently reset to `DeepBloom` (the canonical default per DEC-067, which superseded the per-theme mapping in DEC-054).
- Supabase Edge Function for push-trigger (`supabase/functions/notify-on-message/`): fired by database webhook / trigger on `messages` insert; sends APNs payload.
- App-review-artifact pipeline: separate repo (`.gitignored` subdir of `haptic-app`), git-LFS for screenshot artifacts, Claude skill for review-note generation from spec/takeaway. Built and first-used for the iteration-8 submission.
- Data-collection summary document (part of app-review-artifact pipeline): lists data types collected, retention policy (indefinite), RLS status.
- Privacy Policy document (from template, web-research-gated) hosted at `tryhaptic.com/privacy` (deployed from `haptic-site/public-site`).
- Terms of Service document (from template, web-research-gated) hosted at `tryhaptic.com/terms` (deployed from `haptic-site/public-site`).
- New Supabase migration enabling APNs device-token storage (new `device_tokens` table or equivalent).
- Behavioral verification of `NetworkMonitor` discard-on-loss in `ChatViewModel`: force-disable the network mid-tap, confirm the in-progress tap session is discarded, confirm no partial broadcast is sent, characterize user-visible feedback. On pass, the discard-on-loss path is promoted to a full invariant in iteration 9.

### Modified

- `ThemeProvider.availableThemes`: removes `BrutalistTheme` and merged-out bioluminescent theme from registered list; adds dark glassmorphic theme. Source files for removed themes are retained (dormant) — not `git rm`'d.
- `AppDependencies`: wires `PushNotificationService` and `SettingsViewModel` into the DI graph.
- `SettingsView`: restructured to consume `SettingsViewModel`; profile-name field added; bug-report UI added.
- `AuthView` / `AuthViewController`: browse-wrap legal notice + tappable Privacy Policy and Terms links added below sign-in controls.
- Invite handling: server/DB no longer invalidates invite link after first use (partial update — `[delta-partial]`). iOS client-side dedup unchanged.
- Production app copy sweep: remove/replace misleading language ("Private and Secure" while storing plaintext or similar), beta surfaces, secret-leak candidates.
- `haptic-site/public-site`: remove E2EE claim and "no algorithms" claim (and any other misleading statements found); add Privacy Policy and Terms of Service pages. (`[external]`)

### Removed (from registry; files lie dormant)

- `BrutalistTheme` removed from `ThemeProvider.availableThemes`. Source file retained dormant. `[review-later]`
- Merged-out bioluminescent theme removed from `ThemeProvider.availableThemes`. Source file retained dormant. `[review-later]`
- Original App Icon removed from active `AppIcon` set in `Assets.xcassets`; source asset retained dormant. `[review-later]`

## Invariants `[must not change]`

All 18 iteration-7 invariants carry forward unchanged:

1. `HapticKit` Domain/Data separation; Domain layer has zero external dependencies.
2. Manual DI via `AppDependencies`; no DI framework, no implicit resolution.
3. `AppCoordinator` owns the root `UIWindow` and mediates auth-driven root view swaps.
4. Swift 6 strict concurrency enabled; `@MainActor` on all UI/DI types; `Sendable` audits required when marking types `Sendable`.
5. Haptic engine split via `#if targetEnvironment(simulator)` behind `HapticPlayable`; `MockHapticPlayer` on simulator, `CoreHapticsEngine` on device.
6. `TapInputView` is UIKit for timing-precise touch capture (synchronous `touchesBegan/Ended`, `CACurrentMediaTime()` timestamps, strict single-touch enforcement, direct feed to UIKit effect layers).
7. Dual-framework observation recipe for services bridging both SwiftUI and UIKit: `ObservableObject + @Published + NotificationCenter`. SwiftUI consumers use `@ObservedObject`; UIKit consumers use `NotificationCenter.addObserver` + `applyTheme()`.
8. ViewModel framework rule: UIKit-bridging ViewModels use `ObservableObject + @Published`; SwiftUI-exclusive ViewModels use `@Observable`; dual-framework services use the recipe in invariant #7.
9. Realtime channel logic consolidated in `SupabaseRealtimeRepository`; no separate `ConversationChannel.swift`. Push notifications use APNs (separate transport) and live in a new `PushNotificationService` — not inside `SupabaseRealtimeRepository`.
10. Safety timeout for continuous haptic without an up-event: 4 seconds.
11. Per-message play state (unplayed / playing / played) persists to SwiftData and reloads on next launch.
12. Message pagination: 50 messages per page fetched on scroll-to-top; `hasMoreOlderMessages` flag controls infinite scroll.
13. `newMessageIndicator` floating button appears when the user is scrolled up and a new message arrives.
14. Invite URL deduplication: the same invite URL must never be processed twice regardless of delivery path (SceneDelegate or SwiftUI `onOpenURL`). This is client-side dedup and is orthogonal to the server-side reusability introduced in this iteration.
15. Schema changes exclusively via timestamped migration files; the remote schema is never edited directly.
16. RLS enabled on every table (including any new tables added this iteration).
17. Realtime enablement for a table requires an explicit migration adding it to the `supabase_realtime` publication.
18. CLAUDE.md scope is mechanism-only: no catalog or point-in-time state (file inventories, entity lists, theme tables, feature flags, enabled-feature lists). Catalog belongs in code. No catalog parentheticals inside rules.

## Provisional invariants

Carry forward from iteration 7 unchanged:

1. Theme system mechanism — protocol-based (`HapticThemeProtocol`), runtime-switching (`ThemeProvider.shared`), notification broadcast (`themeDidChangeNotification`), theme-agnostic naming throughout UI code — is the invariant; theme catalog is point-in-time. Trigger: real-world bug-report pressure surfacing mechanism limitations.
2. UIKit theme-switch checklist (observe notification → re-apply all theme-derived properties → reload table data → re-theme cells in `configure()` → re-theme lazy/closure-initialized views) is the required pattern for all UIKit views with theme-derived properties. Trigger: real-world bug-report pressure surfacing checklist gaps.

## Migration

**Theme migration (automatic, on-launch):** `migrateLegacyThemeKeys()` runs during `ThemeProvider.init()` before any UI is presented.
- Any persisted `UserDefaults` theme key that does not resolve to a currently-registered `ThemeID` (i.e., is not in `ThemeID.allCases`) is silently migrated to the default theme (`DeepBloom`).
- Users whose persisted key resolves to a still-registered theme → no change.

No data migration required for other changes: profile `displayName` already exists as a `NOT NULL` column on `profiles` since the initial schema (2026-03-03) — AC2.3 is a UI/use-case addition only, with no schema change. Push tokens are new data with no legacy.

## Constraints

- 36-hour wall clock; target submission 2026-04-28 evening.
- Submission-ready definition: iteration closes on attempted submission, not Apple's approval verdict.
- Minimize 3rd-party vendors (applies especially to bug-report destination and API key protection).
- Cross-repo scope (`[external]` tag) is one-time for this iteration; a future site-repo spec will own site-side ACs going forward.
- No haptic-mimicking push payload research (deferred to a future iteration).
- Data retention indefinite (not ephemeral; auto-deletion would defy user expectations).
- Bug report is Settings-only; no shake-to-report.
- No app-level encryption; Supabase default KMS is the encryption-at-rest solution (web-research verification required).
- No per-theme alternate App Icons (`setAlternateIconName` not used).
- "Lies dormant" deletion convention: when a theme, asset, or file is removed from registries/catalogs this iteration, its source file is retained in the repository (not `git rm`'d). Removal means de-registering from all factory/catalog lists (`ThemeProvider.availableThemes`, `AppIcon` active set, etc.); the file itself remains. Iteration 9 or 10 reconsiders true deletion.
- Invite update is partial only (server-side expire removal); full multi-invitee overhaul stays deferred.

## Success criteria

1. Build uploaded to TestFlight.
2. All required Beta App Review materials provided: App Review Notes (from pipeline), screenshots, metadata, Privacy Policy URL live at `tryhaptic.com/privacy`, Terms of Service URL live at `tryhaptic.com/terms`, data-collection summary.
3. Submission to External Beta Review attempted (pass/fail from Apple not gating).
4. AC14 audit deliverable (realtime-tap edge-case enumeration + repro results + any fixes) is stored before iteration close. AC15 (NetworkMonitor discard-on-loss) is behaviorally verified.

## Out of scope

- Haptic-mimicking push payload research.
- Full invite-system overhaul (reusable multi-invitee links, new invite UX).
- `RealtimeLogView` UX polish, filtering, and export.
- `HapticWaveformView` visual improvements.
- Per-theme App Icon alternation (`setAlternateIconName`).
- True deletion (`git rm`) of dormant theme/logo files (deferred to iteration 9 or 10).
- Any workstream beyond the named bundle.

## Acceptance criteria (MECE)

> **Tag legend:**
>
> - `[delta]` — new or modified behavior introduced by this iteration.
> - `[regression]` — existing behavior that must be preserved (verified in iteration 7; re-confirmed by `/spec verify` this iteration).
> - `[delta-partial]` — partial implementation of a deferred-shelf item; the broader deferral remains valid for the unimplemented portion. Composes with `[delta]`.
> - `[external]` — deliverable lives in another repo (`haptic-site/public-site` or the new app-review-artifact repo); `/spec verify` uses external evidence (URL, sibling-repo file, or commit SHA). Composes with `[delta]`.
> - `[review-later]` — explicit follow-up flagged for iteration 9 or 10 reconsideration (e.g., true deletion of dormant files). Does not require action this iteration. Composes with `[delta]` or `[regression]`.
> - `[adopted]` — de-facto behavior or invariant ratified post-implementation (via `/spec reconcile`); records what shipped without asserting it was deliberated up front. Composes with `[delta]`.

---

### AC1. Push notifications `[delta]`

- AC1.1. The app registers for remote push notifications on first sign-in: `UNUserNotificationCenter.requestAuthorization` is called, and on grant the app calls `UIApplication.shared.registerForRemoteNotifications`. `[delta]`
- AC1.2. The APNs device token is stored in Supabase (new table or column) when received in `AppDelegate.application(_:didRegisterForRemoteNotificationsWithDeviceToken:)`. Token is associated with the authenticated user. `[delta]`
- AC1.3. A Supabase Edge Function (`notify-on-message` or equivalent) fires on each `messages` table insert and sends an APNs push notification to the recipient's registered device token(s). (`supabase/functions/`) `[delta]`
- AC1.4. Push notification payload includes at minimum: sender name (or a placeholder if name unavailable) and a message preview or generic "New message" body. No haptic-mimicking payload fields. `[delta]`
- AC1.5. Receiving a push notification while the app is backgrounded shows the notification in iOS notification center. `[delta]`
- AC1.6. APNs device-token storage uses a new migration file; RLS is enabled on the new table (invariant #16). (`supabase/migrations/`) `[delta]`
- AC1.7. Push notification transport code lives in a new `PushNotificationService` (or `PushNotificationRepository`) — NOT inside `SupabaseRealtimeRepository` (invariant #9 preservation). `[delta]`
- AC1.8. On user sign-out, the device-token row(s) keyed by `(current user, current device token)` are deleted from the Supabase `device_tokens` table (or equivalent) before the local session is cleared. After sign-out completes, the Edge Function from AC1.3 no longer has a recipient row for that user on this device and emits no pushes to it. Best-effort: if the delete fails (offline, transient error), sign-out still proceeds; reconciliation on next sign-in is acceptable. The Edge Function additionally prunes stale device-token rows on APNs `410 Unregistered` / `400 BadDeviceToken` responses using a `service_role` Supabase client (DEC-059). `[delta]`
- AC1.9. While the app is foregrounded, push notifications are suppressed (`UNUserNotificationCenter` delegate's `willPresent` returns empty presentation options) so no banner / sound / badge appears for the active user. `[delta][adopted]`
- AC1.10. Push notification payload carries a `conversation_id` custom key. Tapping a notification routes the app to the corresponding conversation via `AppCoordinator.openConversation`. Cold-start taps are queued in `AppDelegate.pendingConversationTap` and drained once the coordinator is ready. `[delta][adopted]`
- AC1.11. Sign-out displays an interim `SigningOutView` blocking screen for up to 4 seconds while the device-token cleanup runs (per DEC-061). UI proceeds to the auth screen as soon as cleanup completes or the timeout fires, whichever comes first. `[delta][adopted]`

### AC2. Profile-name editor + SettingsViewModel `[delta]`

- AC2.1. `SettingsViewModel` is extracted as a new `@Observable` class (SwiftUI-exclusive per invariant #8); `SettingsView` receives it as an injected `@Bindable` parameter and relies on SwiftUI's automatic observation tracking. `SettingsView` continues to own theme-switching directly via `@ObservedObject` of `ThemeProvider.shared` (the dual-framework recipe per invariant #7); profile-name editing, notification-status polling, and bug-report navigation route through `SettingsViewModel`. `[delta]`
- AC2.2. `SettingsView` contains a profile-name text field showing the user's current display name. `[delta]`
- AC2.3. Saving a profile name: leading/trailing whitespace is trimmed; an empty-after-trim name is rejected with visible inline feedback; a non-empty name triggers `UpdateProfileUseCase` → `UserRepository` → Supabase `profiles` table update. `[delta]`
- AC2.4. Persistence feedback is visible: a loading indicator while the save is in-flight; a success confirmation or error message on completion. `[delta]`
- AC2.5. `SettingsViewModel` is wired through `AppDependencies` and injected by the Coordinator; it is not instantiated directly in `SettingsView`. A single shared `SettingsViewModel` instance persists across all sign-in sessions in one app lifecycle (it is not re-created per Settings presentation). `[delta]`
- AC2.6. Settings contains a Notifications section showing the current `UNAuthorizationStatus` with state-specific UI: `notDetermined` shows an "Enable" button that calls `requestAuthorization`; `authorized` shows the granted state; `denied` shows a deep link to iOS Settings. Status is re-polled when `scenePhase` becomes `.active` so a user returning from iOS Settings sees the updated state. `[delta][adopted]`

### AC3. Browse-wrap legal links on sign-in `[delta]`

- AC3.1. The sign-in screen displays a browse-wrap notice informing the user that by signing in they agree to the Terms of Service and Privacy Policy. `[delta]`
- AC3.2. Tapping "Privacy Policy" in the notice opens `https://tryhaptic.com/privacy` (via `SFSafariViewController` or `UIApplication.open`). `[delta]`
- AC3.3. Tapping "Terms of Service" in the notice opens `https://tryhaptic.com/terms`. `[delta]`
- AC3.4. The browse-wrap notice is visible without requiring scroll on the sign-in screen. `[delta]`

### AC4. Privacy Policy and Terms of Service hosting `[delta][external]`

- AC4.1. **Research outcome recorded:** a web-research AC establishes the chosen Privacy Policy template/approach; the research outcome is recorded in a file within the app-review-artifact repo (or in a spec/decisions supplement). `[delta]`
- AC4.2. Privacy Policy text is drafted from the researched template, covering at minimum: data collected (account info, messages), retention (indefinite), no sale of data, contact method for deletion requests. `[delta][external]`
- AC4.3. Privacy Policy is live at `https://tryhaptic.com/privacy`, deployed from `haptic-site/public-site`. `[delta][external]`
- AC4.4. **Research outcome recorded:** a web-research AC establishes the chosen Terms of Service template/approach; outcome recorded alongside AC4.1. `[delta]`
- AC4.5. Terms of Service text is drafted from the researched template, covering at minimum: acceptable use, disclaimer of warranty, governing law. `[delta][external]`
- AC4.6. Terms of Service is live at `https://tryhaptic.com/terms`, deployed from `haptic-site/public-site`. `[delta][external]`

### AC5. In-app bug-report flow `[delta]`

- AC5.1. **Research outcome recorded:** a web-research AC establishes the bug-report destination architecture under the constraint of minimizing 3rd-party vendors with a human review gate before issuification. The chosen architecture (per DEC-048) is a Supabase `bug_reports` table with RLS, a database webhook firing the `notify-bug-report` Edge Function, which delivers via Gmail SMTP (Google Workspace App Password) to `tech.dev@nascen.tech`. Human review = inbox triage → manual GitHub Issue creation as needed. `[delta]`
- AC5.2. Settings contains a "Report a Bug" entry that opens a bug-report UI (not shake-to-report). `[delta]`
- AC5.3. The bug-report UI contains two required text fields — user description and expected behavior — plus optional structured metadata fields, and a submit button. The submit button is enabled only when both required fields are non-empty after trim. `[delta]`
- AC5.4. On submit, device metadata (iOS version, app version, device model) is appended to the report automatically. `[delta]`
- AC5.5. The submitted report is routed to the destination architecture selected in AC5.1: an authenticated insert to the `bug_reports` table (JSONB payload schema per migration `20260430120000_bug_reports_jsonb_payload.sql`), with a `client_uuid` unique constraint providing per-form-instance idempotency. The database webhook fires `notify-bug-report` which emails the report to the human-review inbox. `[delta]`
- AC5.6. The user sees a confirmation or error after submitting. `[delta]`

### AC6. Supabase encryption-at-rest verification `[delta]`

- AC6.1. **Research outcome recorded:** a web-research AC confirms whether Supabase default KMS provides encryption at rest for stored messages; outcome recorded. `[delta]`
- AC6.2. The app's in-flight compliance posture matches the AC6.1 finding: if KMS encryption at rest is confirmed, no additional app-level encryption layer is added; if not confirmed, a mitigation decision is logged in `spec/decisions.log`. `[delta]`

### AC7. API key and secret-leak sanity check `[delta]`

- AC7.1. **Research outcome recorded:** a web-research AC identifies best-practice non-3rd-party-vendor approaches for protecting API keys / secrets beyond `.gitignore` in a private repo; outcome recorded. `[delta]`
- AC7.2. All secrets (Supabase URL, anon key, service role key, APNs credentials) are confirmed `.gitignored`; no accidental un-ignore paths exist. `[delta]`
- AC7.3. Any additional protection layers identified in AC7.1 that are feasible without 3rd-party vendors are applied (or explicitly deferred with rationale in `decisions.log`). `[delta]`

### AC8. Beta-surface and misleading-copy sweep (app) `[delta]`

- AC8.1. A deliberate human-reviewed sweep of the production app confirms no screen or string reads as "Beta" or contains beta-specific language. `[delta]`
- AC8.2. Any copy implying stronger security guarantees than Supabase KMS-at-rest (e.g., "Private and Secure" with no qualifier, "End-to-End Encrypted") is removed or corrected. `[delta]`
- AC8.3. `#if DEBUG`-gated sections are confirmed absent from the App Review (production) build. `[delta]`

### AC9. Misleading-copy sweep (site) `[delta][external]`

- AC9.1. The E2EE claim is removed from `haptic-site/public-site`. `[delta][external]`
- AC9.2. The "no algorithms" claim is removed from `haptic-site/public-site`. `[delta][external]`
- AC9.3. A deliberate sweep of all public-site copy finds and removes (or corrects) any other claims materially inconsistent with the app's current reality. `[delta][external]`

### AC10. New dark third theme + new logo `[delta]`

- AC10.1. A new dark third theme (concrete class conforming to `HapticThemeProtocol`) is implemented and registered in `ThemeProvider.availableThemes`. Specific visual mechanism (glassmorphism, gradient field, etc.) is an implementation choice, not a spec requirement. `[delta]`
- AC10.2. The new theme is selectable at runtime from the theme picker in Settings and applies correctly to all themed surfaces (invariant #2 / provisional invariant #2). `[delta]`
- AC10.3. A new logo asset is created and replaces the in-app brand asset. `[delta]`
- AC10.4. `Assets.xcassets/AppIcon` is updated with the new logo at 1024×1024 and all required size variants; the new icon appears as the home-screen app icon on device. `[delta]`
- AC10.5. No per-theme alternate App Icons are configured (`setAlternateIconName` is not called). `[delta]`

### AC11. Theme registry cleanup + migration `[delta]`

- AC11.1. `BrutalistTheme` is absent from `ThemeProvider.availableThemes` (and any equivalent registered-theme list); its source file is retained in the repo at `Presentation/Theme/Dormant/BrutalistTheme.swift` and excluded from the build target (the file references `ThemeID.brutalist`, which no longer exists, so it does not compile if re-added to the target). `[delta][review-later]`
- AC11.2. The merged-out bioluminescent theme is absent from `ThemeProvider.availableThemes`; its source file is retained at `Presentation/Theme/Dormant/BioluminescentTheme.swift` under the same build-target-exclusion mechanism as AC11.1. `[delta][review-later]`
- AC11.3. Original App Icon asset is not referenced by the active `AppIcon` set in `Assets.xcassets`; the source file is present in the repo (dormant). `[delta][review-later]`
- AC11.4. `migrateLegacyThemeKeys()` runs in `ThemeProvider.init()`: any persisted `UserDefaults` theme key that does not resolve to a currently-registered `ThemeID` is migrated to the default theme (`DeepBloom`); users on a still-registered theme are unaffected. `[delta]`
- AC11.5. `DeepBloom` is the canonical bioluminescent-family theme in the registered list and is unaffected by the migration. `[delta]`

### AC12. Partial invite-link update `[delta][delta-partial]`

- AC12.1. The server/DB no longer invalidates an invite link after its first use; the same link can be redeemed by a second user without error. `[delta][delta-partial]`
- AC12.2. Client-side invite URL dedup (`resolvingInviteCodes: Set<String>` in `AppCoordinator`) is unchanged and still functions correctly (invariant #14 preservation). `[regression]`

### AC13. App-review-artifact pipeline `[delta][external]`

- AC13.1. The app-review-artifact repo exists as a `.gitignored` subdirectory of `haptic-app`, with git-LFS configured for screenshot artifacts. `[delta][external]`
- AC13.2. The repo contains a Claude skill that, when invoked, generates App Review Notes (review-ready text) from the current `spec/spec.md` and `spec/takeaway.md`. `[delta][external]`
- AC13.3. The repo has a defined directory structure for per-iteration artifacts (screenshots, metadata, review notes, data-collection summary). `[delta][external]`
- AC13.4. The pipeline is used for the iteration-8 submission: iteration-8 App Review Notes are generated by the skill; screenshots and metadata are captured and stored in the repo; the data-collection summary is present. `[delta][external]`

### AC14. Realtime-tap edge-case audit `[delta]`

- AC14.1. A 4-hour-timebox audit is conducted: enumerate edge-case scenarios for realtime-tap delivery failures (channel subscription race, mid-session network flap, duplicate broadcast, sequence ordering, etc.). Deliverable is a written enumeration of scenarios + careful reasoning about each. `[delta]`
- AC14.2. For each hypothesized scenario, a local repro is attempted; findings (reproduced / not reproduced / inconclusive) are recorded. `[delta]`
- AC14.3. Speculative fixes are applied for any scenario where the cause is identified with high confidence and the fix is low-risk; each fix is noted with its target scenario. Audit may conclude with zero fixes applied — this is an acceptable outcome. `[delta]`
- AC14.4. The audit report (enumeration + reasoning + repro results + any fixes) is stored under `papertrail/report/` before the iteration closes. `[delta]`

### AC15. NetworkMonitor discard-on-loss verification `[delta]`

- AC15.1. With `ChatViewModel` mid-tap (a session in progress), the network is force-disabled (Network Link Conditioner, airplane mode, or test harness equivalent) and the in-progress tap session is confirmed to be discarded — no partial sequence is broadcast over `SupabaseRealtimeRepository`. `[delta]`
- AC15.2. The user-visible feedback on mid-tap network loss is characterized (silent discard / banner / toast / error message) and recorded under `papertrail/report/` so iteration 9 can decide whether the UX is acceptable. `[delta]`
- AC15.3. The discard-on-loss code path is recorded in `spec/decisions.log` as a candidate for promotion to a full invariant in iteration 9; the iteration-9 spec will carry the promotion if no regression is found in the interim. `[delta]`
- AC15.4. Persist-failure rollback: if the post-session persist (or `sendPattern` / `sendTextMessage`) fails after the optimistic insert, the locally-inserted message is removed from `messages` and `LocalDataSource`, and a transient error banner is shown. The local cache and remote state never diverge silently on persist failure. `[delta][adopted]`
- AC15.5. Touch-cancel handling: if `touchesCancelled` fires mid-session (OS gesture interruption — phone call, system alert, etc.), the in-progress haptic session is discarded with the same semantics as a network-loss discard (no partial broadcast, no message produced). `[delta][adopted]`
- AC15.6. Foreground channel refresh: on `UIApplication.willEnterForegroundNotification`, `ChatViewModel` triggers a realtime channel refresh to recover from zombied WebSocket connections that survived background suspension but no longer deliver inserts. After the re-subscribe completes, `loadRemoteMessages` runs as a REST catch-up — the Postgres listener only delivers INSERTs that occur after subscription, so messages that arrived during the background window are otherwise unreachable; the catch-up merges them in via the standard `addMessageIfNew` ID-deduplicated path. `[delta][adopted]`
- AC15.7. Lightweight reactivation catch-up: on `UIApplication.didBecomeActiveNotification`, `ChatViewModel` performs the same REST catch-up (`loadRemoteMessages` + read-stamp bump) without tearing down the WebSocket. Covers brief active→inactive→active flips (Control Center swipe, call banners, app switcher peek) that do not fire `willEnterForeground`. Guarded by `!isRefreshingChannel && isConnected` so it defers to the heavy refresh path when that's already running and is a no-op during the initial connect. `[delta][adopted]`

### AC16. Architecture regression checks `[regression]`

- AC16.1. `HapticKit/Sources/Domain/` contains only pure Swift with zero external dependencies. `[regression]`
- AC16.2. `AppDependencies` remains the single manual DI factory; all new services (push, settings VM) are wired in its `init()`. `[regression]`
- AC16.3. `Message.Content` enum retains exactly two cases: `.haptic(sequence:label:icon:)` and `.text(String)`. `[regression]`
- AC16.4. Realtime channel logic remains consolidated in `SupabaseRealtimeRepository`; no separate `ConversationChannel.swift` appears. `[regression]`
- AC16.5. `TapInputView` remains a UIKit `UIView` with `CACurrentMediaTime()` timestamps and single-touch enforcement. `[regression]`
- AC16.6. `ChatViewModel` safety timeout remains 4 seconds. `[regression]`
- AC16.7. Per-message play state persists to SwiftData and reloads on next launch. `[regression]`
- AC16.8. `newMessageIndicator` floating button behavior is unchanged. `[regression]`
- AC16.9. Message pagination (50 per page, `hasMoreOlderMessages` flag) is unchanged. `[regression]`
- AC16.10. `AuthViewController` remains a pure `UIHostingController<AuthView>` with no UIKit logic of its own. `[regression]`
- AC16.11. `AuthViewModel` remains `@Observable` (SwiftUI-exclusive). `[regression]`
- AC16.12. Schema changes for this iteration use new timestamped migration files; no direct schema edits. `[regression]`
- AC16.13. RLS is enabled on all tables including any new ones introduced by push-notification token storage. `[regression]`

### AC17. Adopted invariants (mid-implementation ratifications) `[adopted]`

> Added via `/spec reconcile` (iteration 8). Each item ratifies de-facto behavior or a load-bearing assumption present in iteration-8 code.

- AC17.1. **Auth-state expired-JWT recovery.** `AppCoordinator.observeAuthState()` detects an expired JWT (`tokenRefreshFailed` or expired-session signal) and attempts `supabaseClient.auth.refreshSession()` before falling back to `showAuth()`; users are not silently bounced to the auth screen on transient session expiry. `[adopted]`
- AC17.2. **`PushNotificationService` singleton-by-convention.** Exactly one `PushNotificationService` instance is created per app lifecycle; the type is `NSObject` and registers itself as `UNUserNotificationCenter.current().delegate` in its `init`. The DI graph guarantees this; the type itself does not enforce it. `[adopted]`
- AC17.3. **Sign-out cleanup ordering.** `AppCoordinator.signOut()` races the device-token cleanup against a 4-second `Task.sleep` via `withTaskGroup`. The cleanup must run while the JWT is still valid (RLS gate); the sleep ensures sign-out cannot block indefinitely. After whichever finishes first, `auth.signOut()` runs synchronously on the `MainActor`. `[adopted]` (See DEC-061.)
- AC17.4. **Bug-report idempotency scope.** `BugReportViewModel.clientUUID` is regenerated on each `reset()` (called in `BugReportView.onAppear`). The `bug_reports.client_uuid` unique constraint protects against duplicate submissions of the same form instance, not against a user filing the same report twice across distinct screen entries. `[adopted]`
- AC17.5. **`NWPathMonitor` startup race.** `DeviceMetadataProvider` starts its `NWPathMonitor` in `init()`; between launch and the first path-update callback, `currentNetworkType` reads as `"unknown"`. Bug reports submitted in this window carry `"unknown"` as the network type and are accepted as such. `[adopted]`
- AC17.6. **Realtime / remote-fetch dedup contract.** `ChatViewModel.connect()` opens the realtime subscription before the remote message fetch completes (`async let`). If a real-time `INSERT` broadcast arrives for a message also returned by the remote fetch, `addMessageIfNew` deduplicates by `id`. The deduplication is the silent contract that makes this ordering safe. `[adopted]`

### AC18. Read-state architecture `[delta][adopted]`

> Added via `/spec reconcile` (iteration 8). Replaces the prior server-only read tracking (`conversation_participants.last_read_at` consulted directly by `Conversation.hasUnread`) with a client-local source of truth + eventually-consistent server mirror. Eliminates the cold-start "still unread after closing the chat" symptom whose root cause was `disconnect()`'s fire-and-forget `updateLastReadAt` Task being cancelled when the OS suspended the app.

- AC18.1. **Client-local source of truth.** `LocalConversationReadState` (SwiftData `@Model`, unique on `conversationId`, fields `lastReadAt: Date` and `lastSyncedAt: Date?`) is the source of truth for the unread badge on this device. `ConversationListViewModel.displayData(for:)` computes the badge by comparing the conversation's server-authored `lastMessageAt` against the local `lastReadAt`, not against `participant.lastReadAt`. `[delta][adopted]`
- AC18.2. **Server is an eventually-consistent mirror.** `conversation_participants.last_read_at` is no longer consulted for the badge on this device; it is written opportunistically by `ReadStateSyncCoordinator` so other devices and future server-side features (push badges, read receipts) can consume an up-to-date value. `[delta][adopted]`
- AC18.3. **Watermark sync, not boolean dirty bit.** A conversation is dirty when `localLastReadAt > lastSyncedAt`. On a successful push of captured stamp `V`, `lastSyncedAt` advances to `V`. If the local stamp moved past `V` during the round trip, the row is still dirty by comparison and the next trigger re-flushes — eliminating the stale-write race a boolean flag would suffer. `[delta][adopted]`
- AC18.4. **Server-authored stamp values.** The local `lastReadAt` is sourced from `Message.createdAt` (server-authored), never client `Date()`. This makes the comparison against `lastMessageAt` apples-to-apples and immune to client/server clock skew. `[delta][adopted]`
- AC18.5. **Stamp bump triggers.** `ChatViewModel` bumps the local stamp via `ReadStateSyncCoordinator.recordLocalRead(value:)` at: (a) every successful `loadRemoteMessages` call — bumped to the latest visible message createdAt — which covers the initial connect, `willEnterForeground` channel refresh (`refreshChannelOnForeground`), and `didBecomeActive` reactivation catch-up (`catchUpOnReactivation`); the bump is owned by `loadRemoteMessages` itself rather than by each caller, so any future REST catch-up entry point inherits it; (b) every `addMessageIfNew` arrival (Postgres / `session_complete` / pattern broadcast); (c) every self-sent message append. No bump on chat-close — chat-close adds no new information beyond what the per-arrival and per-fetch bumps already captured. `[delta][adopted]`
- AC18.6. **Server flush triggers.** `AppCoordinator` invokes `ReadStateSyncCoordinator.flushAll()` at app launch, on `UIApplication.willEnterForegroundNotification`, and on each network-becomes-available edge (via `NetworkMonitor.$isConnected.removeDuplicates().filter { $0 }`). A pending push that died with the previous session's task is durably retried because the watermark lives in SwiftData. `[delta][adopted]`
- AC18.7. **Per-conversation in-flight serialization.** The coordinator (a Swift `actor`) holds an `inFlight: Set<UUID>` so two pushes for the same conversation cannot complete out of order and overwrite a newer watermark with an older one. After a successful push the coordinator re-checks the row and tail-flushes if the local stamp advanced during the round trip. `[delta][adopted]`
- AC18.8. **Seed on first encounter.** `seedLocalReadStateIfMissing` (called from `ConversationListViewModel.reloadConversations` for each fetched conversation) inserts a row with `lastReadAt = lastSyncedAt = participant.lastReadAt` when no local row exists. Mirrors the server's value on a fresh install or new device so existing-history conversations don't all flash as unread. The seeded row is non-dirty, so no redundant push fires. `[delta][adopted]`
- AC18.9. **Domain protocol signature.** `MessageRepository.updateLastReadAt(conversationId:value:)` accepts the captured stamp value explicitly. Callers pass the value they captured at flush-start, never `Date()`, so a slow round-trip cannot accidentally regress a stamp that advanced locally during the push. `[delta][adopted]`

### AC19. Chat UX — animated message arrivals `[delta][adopted]`

> Added via `/spec reconcile` (iteration 8). Replaces `tableView.reloadData()` snap-in with an animated `insertRows` slide for the common "new message appended at the end" case.

- AC19.1. **Pure-append animation.** When `viewModel.$messages` emits a new array that is a strict prefix-extension of the previous one (every previously-known ID still present in the same positions, one or more new IDs appended at the end), the chat table animates the new arrivals via `tableView.performBatchUpdates { insertRows(at:[row 0..k-1], with: .top) }`. In the y-flipped table, `RowAnimation.top` renders as a slide-up from below the visual bottom edge — bubbles "rise" into view. `[delta][adopted]`
- AC19.2. **Fallback to reload.** Any non-pure-append mutation (initial load, send-failure rollback that removes an optimistic message, modality reload from `$messageModalities`, large remote merge that re-sorts) falls through to `tableView.reloadData()`. The pagination handler is excluded from the animated path by the existing `isPaginatingOlder` early-return — older messages append at higher row indices and don't need the slide-up effect. `[delta][adopted]`
- AC19.3. **Diff state.** `ChatViewController.previousMessageIds: [UUID]` tracks the previous emission's full ordered ID list. Updated at the end of every `$messages` sink invocation and inside the pagination completion to keep state aligned with what the table currently shows. `[delta][adopted]`

---

## Implementation phases

> Only `[delta]` ACs (including `[delta-partial]`) are phased here. `[regression]` ACs are verification targets, not implementation work. Phase N is fully implementable without work from phase N+1 — dependencies flow backward only.

### Phase 1. Research gate + encryption posture

**Delivers:** All web-research-gated decisions resolved and recorded, unblocking Privacy/Terms drafting, bug-report implementation, encryption posture, and secret-leak hardening. Encryption-posture compliance claim aligned to the AC6.1 finding (mitigation logged to `decisions.log` if KMS-at-rest is not confirmed).
**Unblocks:** Phases 2, 3, 5, and 6 (each depends on at least one research outcome).

- AC4.1 (Privacy Policy template research)
- AC4.4 (Terms of Service template research)
- AC5.1 (bug-report destination research)
- AC6.1 (Supabase encryption-at-rest verification)
- AC6.2 (encryption-posture alignment / mitigation decision)
- AC7.1 (API key / secret-leak best practices research)

### Phase 2. App-review-artifact pipeline

**Delivers:** External pipeline repo exists, structured, and ready to receive iteration-8 artifacts; Claude skill working.
**Unblocks:** Phase 12 (submission-readiness assembly uses this pipeline to capture artifacts via AC13.4).
**Depends on:** nothing (standalone repo work).

- AC13.1
- AC13.2
- AC13.3

### Phase 3. Privacy Policy and Terms hosting

**Delivers:** Both legal documents live at `tryhaptic.com/privacy` and `tryhaptic.com/terms` — URLs the browse-wrap links can point to.
**Unblocks:** Phase 4 (browse-wrap links need live URLs).
**Depends on:** Phase 1 (template research outcomes for AC4.2 and AC4.5).

- AC4.2 (Privacy Policy text)
- AC4.3 (Privacy Policy deployed)
- AC4.5 (Terms text)
- AC4.6 (Terms deployed)

### Phase 4. Browse-wrap + legal links on sign-in

**Delivers:** Sign-in screen carries working browse-wrap notice with tappable Privacy/Terms links.
**Depends on:** Phase 3 (live URLs at `tryhaptic.com`).

- AC3.1
- AC3.2
- AC3.3
- AC3.4

### Phase 5. Bug-report flow in Settings

**Delivers:** Working in-app bug-report UI in Settings with device metadata and functional submission to researched destination.
**Depends on:** Phase 1 (AC5.1 destination decision), Phase 6 (SettingsViewModel must exist for the bug-report UI to attach to).

- AC5.2
- AC5.3
- AC5.4
- AC5.5
- AC5.6

### Phase 6. SettingsViewModel + profile-name editor

**Delivers:** `SettingsViewModel` extracted; profile-name editor functional in Settings.
**Unblocks:** Phase 5 (Settings UI work depends on VM existing).
**Depends on:** nothing blocking (can start in parallel with Phases 1–3, but Phase 5 must wait for this).

- AC2.1
- AC2.2
- AC2.3
- AC2.4
- AC2.5

### Phase 7. Pulse theme + new logo + theme cleanup

**Delivers:** New theme registered and selectable; legacy themes de-registered with migration; new App Icon in place.
**Depends on:** nothing (isolated theme-system work).

- AC10.1
- AC10.2
- AC10.3
- AC10.4
- AC10.5
- AC11.1
- AC11.2
- AC11.3
- AC11.4
- AC11.5

### Phase 8. Push notifications

**Delivers:** Server-triggered APNs push notifications working end-to-end for incoming messages.
**Depends on:** Phase 1 (encryption/security posture must be settled before adding new Supabase infrastructure).

- AC1.1
- AC1.2
- AC1.3
- AC1.4
- AC1.5
- AC1.6
- AC1.7
- AC1.8

### Phase 9. Secret-leak hardening + sweeps

**Delivers:** API key / secret hygiene confirmed or improved; production app and site copy cleaned of misleading language and beta surfaces.
**Depends on:** Phase 1 (AC7.1 research outcome), Phase 7 (new theme means new copy to review), Phase 8 (complete feature set to sweep).

- AC7.2
- AC7.3
- AC8.1
- AC8.2
- AC8.3
- AC9.1
- AC9.2
- AC9.3

### Phase 10. Partial invite update

**Delivers:** Invite links reusable indefinitely on the server side; client-side dedup unchanged.
**Depends on:** nothing blocking (isolated backend migration).

- AC12.1

### Phase 11. UX preconditions (realtime-tap fix-or-defer + NetworkMonitor verification)

**Delivers:** Both known UX-precondition issues are addressed before opening the external-beta gate. AC14 produces an audit deliverable (scenario enumeration + reasoning + repro results + any speculative fixes); zero fixes is an acceptable outcome. AC15 produces behavioral evidence that mid-tap network loss discards the in-progress session and broadcasts no partial sequence.
**Depends on:** nothing blocking; can overlap with earlier phases.

- AC14.1
- AC14.2
- AC14.3
- AC14.4
- AC15.1
- AC15.2
- AC15.3

### Phase 12. Submission-readiness assembly

**Delivers:** Build uploaded to TestFlight; all required materials captured in artifact pipeline; submission attempted.
**Depends on:** Phases 2–11 (all delta work complete).

- AC13.4 (pipeline used for submission artifacts)

---

## Open questions

None. All clarity-gate axes confirmed by user on 2026-04-27. Web-research-gated decisions are resolved in Phase 1 research ACs, not treated as open questions blocking the spec.
