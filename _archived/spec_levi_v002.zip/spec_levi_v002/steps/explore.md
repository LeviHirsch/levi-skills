# /spec explore — Interpretive synthesis over project materials

Broader synthesis pass over user-specified files or directories. Produces an advisory report tagged `[from-explore]`. Higher contamination risk than extract — output is labeled speculative throughout and must pass through the interview before it can influence the spec.

## State machine

**Allowed from phases:** `interviewing` · `seeded` · `in-review` · `revised`
**Transitions to:** same phase (no phase change)
**Re-run behavior:** Allowed. Each run produces a new archive file. `latest_explore` in state.yaml always points to the most recent.

Read state.yaml first; validate phase. Write state.yaml on completion.

## What explore is for

Explore is *generative*: it finds connections, patterns, and implications the user may not have named. Useful when the project has adjacent materials (prior docs, related directories, partially-formed ideas) that haven't been formally imported into `context/` but may contain relevant context.

Key invariant: **everything in an explore report is labeled advisory** (`[from-explore]`). The interviewer may reference it as leads; the seed step treats it as background context, not ground truth. The user must explicitly promote any `[from-explore]` finding to `[from-user]` or `[from-docs]` via the interview before it flows into spec ACs.

Distinction from related commands:
- **`/spec extract`** — `context/` only, no synthesis, structured output. Run first if you have imported documents.
- **`/spec explore`** — broader scope, synthesis allowed, advisory output. Run when you want the agent to make connections across project materials.
- **`/spec research`** — web-enabled, citations required. Run when you need external facts.

## Protocol

1. **Ask the user for scope.** "Which files or directories should I explore? List paths relative to the project root. If you want me to synthesize across everything in the project dir (excluding `spec/` and `context/`), say 'all'."

2. **Ask for focus questions (optional).** "Any specific questions you want me to try to answer from these materials? Leave blank for an open synthesis." Record questions — they become the explore report's opening section.

3. **Spawn Explore sub-agent.** Use `subagent_type: "Explore"` and `model: "sonnet"`. The prompt must include the **write-fallback instruction from SKILL.md principle 7**. Prompt:

   > You are performing an interpretive synthesis pass over project materials. Your mandate is broader than extract: you may synthesize across documents, identify patterns, surface tensions, and note implications. However, all output must be labeled advisory — you are providing leads for the interviewer and user to evaluate, not ground-truth facts.
   >
   > Scope (paths to read): `<user-specified paths — absolute paths>`
   > Focus questions (if any): `<user-provided questions, or "none — open synthesis">`
   >
   > **Scope constraint:** Read ONLY files within the paths listed above. Do not follow references, imports, or links to files outside this scope. Do not make any web requests. If a file references an external document that might be relevant, note it in Tensions and gaps rather than fetching it.
   >
   > Produce the file at `<absolute path: spec/archive/v<NNN>-YYYY-MM-DD-HHMM-explore.md>` with these sections:
   >
   > ## Explore report — advisory only
   > *All findings in this report are `[from-explore]` — speculative leads, not established facts. Nothing here flows into the spec without passing through the interview.*
   >
   > ### Focus question responses
   > (Only if focus questions were provided.) One subsection per question. Cite the specific files that informed each response.
   >
   > ### Patterns and connections
   > Cross-document patterns, recurring themes, or connections the user may not have named. One bullet per pattern. Cite supporting files.
   >
   > ### Tensions and gaps
   > Places where materials pull in different directions, or where something is conspicuously absent. One bullet per item.
   >
   > ### Leads for the interview
   > Questions this synthesis raises that the interview should address. Framed as Socratic questions, not recommendations.
   >
   > Do not write an executive summary. Do not recommend specific actions. Label every section header with `[from-explore]`.
   >
   > Attempt the Write tool for the target path. If denied, retry once; if still denied, include the full intended file content verbatim in your final reply inside a fenced code block labeled with the target absolute path, so the parent session can write it. Never report success without either having written the file or having dumped its full content.

4. **Verify the file exists.** After the sub-agent returns, check whether the archive file was written. If not, write it from the dumped content.

5. **Present summary.** Report how many patterns, tensions, and leads were found. Tell the user:
   > "Review `spec/archive/<filename>`. Leads that resonate can be surfaced as questions in `/spec interview` or used as background when running `/spec seed`. Nothing from this report flows into the spec without passing through the interview — the `[from-explore]` label is a reminder of that."

6. **Update state.yaml:** `latest_explore: <archive filename>`, `last_command: /spec explore`, `last_command_at: <timestamp>`. Phase unchanged.

7. **Propose commit:**
   ```
   git add spec/archive/<filename> spec/state.yaml
   git commit -m "spec: explore v<n>"
   ```
