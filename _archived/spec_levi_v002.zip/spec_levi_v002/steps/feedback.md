# /spec feedback — Skill feedback log

Record feedback, suggestions, or local adjustments to `~/.claude/skills/spec/FEEDBACK.md` for later sharing with the skill author.

## State machine

**Allowed from phases:** any (feedback is independent of spec project state)
**Transitions to:** unchanged
**Re-run behavior:** always allowed.

## Sections

The feedback file has four sections. Route each entry to the right one:

| Section | When to use |
|---|---|
| **Feedback & Suggestions** | UX observations, missing commands, confusing behavior, feature ideas |
| **Local Adjustments** | Any change made to a file under `~/.claude/skills/spec/` |
| **Open Questions** | Things the user is unsure about or wants to investigate further |
| **Resolved / Reported** | Items already sent to the author or no longer relevant |

## Entry formats

### Feedback & Suggestions entry

Append under the appropriate themed sub-heading (create one if no good match exists):

```markdown
- **<short title>:** <one to three sentences describing the observation or suggestion>
```

### Local Adjustments row

Append one or more rows to the table under `## Local Adjustments`. All changes belonging to the same logical adjustment share the same `Adj` number (increment from the highest existing number). If adding multiple files for one adjustment, repeat the same `#N` across all rows.

```markdown
| #N | YYYY-MM-DD | <relative file path> | <what changed> | <why> |
```

### Open Questions entry

Append a bullet under `## Open Questions`:

```markdown
- <question>
```

### Resolved / Reported entry

Move or append under `## Resolved / Reported`:

```markdown
- **<date>** — <original title>: <one sentence on resolution or how it was reported>
```

## Protocol

1. **Determine type.** If the user ran `/spec feedback` with trailing text, parse intent from it. Otherwise ask:
   > "What kind of feedback? (suggestion / local adjustment / open question / resolved)"

2. **Collect details** per the chosen type:
   - *Suggestion* — ask for a short title and description. Ask which theme it fits (UX, command interface, etc.) or propose a new theme.
   - *Local adjustment* — ask which file was changed, what the change was, and why.
   - *Open question* — accept the question as stated; optionally reword for clarity.
   - *Resolved* — ask which item is resolved and how.

3. **Append** to `~/.claude/skills/spec/FEEDBACK.md` using the appropriate format above. Show the appended text back to the user.

4. **No state.yaml update and no commit proposal** — this file lives in the skill directory, not in the user's project.
