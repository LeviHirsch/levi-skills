---
name: download-fonts
description: Downloads free fonts (TTF/OTF/WOFF2) by name into a local directory. Use this skill whenever the user asks to download, install, or fetch a font — including requests like "get me Inter font", "download Roboto Bold", "I need the Fira Code font files", or any mention of downloading/getting font files. Also trigger when the user references needing font files for a project (e.g., "add the Poppins font to my assets folder").
---

# Download Fonts

Download free font files by name into a local directory, verifying availability and fetching the correct weights from official sources.

## Step 1: Gather requirements

Extract from the user's message:
- **Font name** (required) — e.g., "Inter", "Fira Code", "Playfair Display"
- **Weights** (optional) — e.g., "Regular and Bold", "all weights", "400 700". If unspecified, infer from context: if the user is building a UI, default to Regular (400) + Bold (700). If no context clues, download all available weights.
- **Format preference** (optional) — TTF, OTF, or WOFF2. Default to TTF since it has the widest compatibility.
- **Target directory** (optional) — where to save the files.

If the target directory was not specified, ask the user where they'd like the font files saved before proceeding. Suggest a reasonable default based on the project context (e.g., `./fonts/`, `./assets/fonts/`, or `~/Downloads/fonts/`).

Common weight name mappings (use these to translate user requests like "Bold" into numeric weights):
| Weight | Names |
|--------|-------|
| 100 | Thin, Hairline |
| 200 | ExtraLight, UltraLight |
| 300 | Light |
| 400 | Regular, Normal |
| 500 | Medium |
| 600 | SemiBold, DemiBold |
| 700 | Bold |
| 800 | ExtraBold, UltraBold |
| 900 | Black, Heavy |

## Step 2: Try Google Fonts CSS API first (most fonts are here)

The Google Fonts CSS2 API is the fastest way to get font files — it returns direct download URLs for individual weight files, no ZIP extraction needed. Most popular free fonts are on Google Fonts.

### 2a: Verify the font exists and get download URLs

Make a single curl request to the CSS API. Replace spaces in the font name with `+`:

**If user wants specific weights:**
```bash
curl -sH "User-Agent: Mozilla/5.0" "https://fonts.googleapis.com/css2?family=FONT+NAME:wght@400;700"
```

**If user wants all weights** (use range syntax — the API only returns weights that actually exist):
```bash
curl -sH "User-Agent: Mozilla/5.0" "https://fonts.googleapis.com/css2?family=FONT+NAME:wght@100..900"
```

**If user also wants italic variants**, add the `ital` axis:
```bash
curl -sH "User-Agent: Mozilla/5.0" "https://fonts.googleapis.com/css2?family=FONT+NAME:ital,wght@0,100..900;1,100..900"
```

**Check the response:**
- If it returns CSS with `@font-face` blocks containing `url(https://fonts.gstatic.com/...)` — the font exists. Proceed to 2b.
- If it returns HTTP 400 or an HTML error page containing "Font family not found" — the font is not on Google Fonts. Proceed to Step 3 (fallback).

### 2b: Download each font file

Parse the CSS response to extract weight + URL pairs, then download each file:

```bash
mkdir -p TARGET_DIR

# Parse and download each weight
# The CSS contains blocks like:
#   font-weight: 400;
#   src: url(https://fonts.gstatic.com/s/inter/v20/....ttf) format('truetype');

# Extract weights and URLs, then download
CSS=$(curl -sH "User-Agent: Mozilla/5.0" "https://fonts.googleapis.com/css2?family=FONT+NAME:wght@WEIGHTS")
current_weight=""
echo "$CSS" | while IFS= read -r line; do
  weight=$(echo "$line" | sed -n 's/.*font-weight: \([0-9]*\).*/\1/p')
  url=$(echo "$line" | sed -n 's/.*url(\([^)]*\)).*/\1/p')
  if [ -n "$weight" ]; then
    current_weight=$weight
  fi
  if [ -n "$url" ]; then
    curl -sL "$url" -o "TARGET_DIR/FontName-${current_weight}.ttf"
  fi
done
```

Replace `FontName` with the actual font family name (no spaces, e.g., `Inter`, `FiraCode`, `PlayfairDisplay`).

After downloading, verify the files:
```bash
# Check files exist and are valid (real TTFs are >10KB)
ls -la TARGET_DIR/*.ttf
file TARGET_DIR/*.ttf
```

The `file` command should report "TrueType Font data" for each file. If any file is an HTML error page or is under 1KB, something went wrong.

**Done!** Report to the user what was downloaded and where. Skip to Step 4.

## Step 3: Fallback for non-Google Fonts

If the font isn't on Google Fonts, use WebSearch to find the official source:

```
"[Font Name]" font download free site:github.com OR site:fontsquirrel.com
```

If no results, broaden the search: `"[Font Name]" font download official`. Maximum 2 web searches total.

### GitHub releases (common for developer fonts)

Many popular fonts have official GitHub repos (e.g., `rsms/inter`, `tonsky/FiraCode`, `JetBrains/JetBrainsMono`):

```bash
gh api repos/OWNER/REPO/releases/latest --jq '.tag_name, (.assets[] | "\(.name) \(.browser_download_url)")'
```

Download the appropriate asset (usually a ZIP), extract with `unzip -j -o`, and keep only the desired weight files.

If `gh` is not available, use WebFetch on `https://api.github.com/repos/OWNER/REPO/releases/latest`.

### Font Squirrel or other sources

1. WebFetch the download page to find the direct download link
2. Download with `curl -sL`
3. If it's a ZIP, extract with `unzip -j -o` and filter to desired weights/formats

### Font not found anywhere

If you can't verify the font exists as a free font after 2 searches, tell the user:
- The font wasn't found as a freely available download
- Suggest similar free alternatives if possible
- Ask if the font name might be spelled differently

## Step 4: Report results

List what was downloaded:
```bash
ls -la TARGET_DIR/*.ttf TARGET_DIR/*.otf 2>/dev/null
```

Tell the user:
- Which font files were downloaded and their location
- Which weights are included
- File count and total size

Always use `\rm` (backslash-escaped) instead of plain `rm` for any cleanup to bypass the interactive alias.
