#!/bin/bash
# Xcode Project Validation Script
# Checks for common configuration issues

set -e

ERRORS=0
WARNINGS=0

echo "🔍 Validating Xcode project configuration..."
echo ""

# Find .xcodeproj file
XCODEPROJ=$(find . -maxdepth 1 -name "*.xcodeproj" -print -quit)

if [ -z "$XCODEPROJ" ]; then
    echo "❌ ERROR: No .xcodeproj file found in current directory"
    exit 1
fi

PBXPROJ="$XCODEPROJ/project.pbxproj"

if [ ! -f "$PBXPROJ" ]; then
    echo "❌ ERROR: project.pbxproj not found in $XCODEPROJ"
    exit 1
fi

echo "📦 Found project: $XCODEPROJ"
echo ""

# Check 1: Info.plist conflict detection
echo "✓ Checking for Info.plist conflicts..."

HAS_GENERATE_INFOPLIST=$(grep -c "GENERATE_INFOPLIST_FILE = YES" "$PBXPROJ" || true)
HAS_INFOPLIST_FILE=$(grep -c "INFOPLIST_FILE = " "$PBXPROJ" || true)

if [ "$HAS_GENERATE_INFOPLIST" -gt 0 ] && [ "$HAS_INFOPLIST_FILE" -gt 0 ]; then
    echo "  ❌ CRITICAL: Info.plist conflict detected!"
    echo "     Both GENERATE_INFOPLIST_FILE=YES and INFOPLIST_FILE are set"
    echo "     Remove INFOPLIST_FILE setting from build configuration"
    ERRORS=$((ERRORS + 1))
else
    echo "  ✅ No Info.plist conflicts"
fi

# Check 2: Physical Info.plist when using auto-generation
if [ "$HAS_GENERATE_INFOPLIST" -gt 0 ]; then
    # Find all directories that might contain source files
    SOURCE_DIRS=$(find . -maxdepth 2 -type d \( -name "Sources" -o -name "*.app" -o -name "*[!Tests]" \) 2>/dev/null || true)

    for dir in $SOURCE_DIRS; do
        if [ -f "$dir/Info.plist" ]; then
            echo "  ⚠️  WARNING: Found physical Info.plist at $dir/Info.plist"
            echo "     This file is not needed when GENERATE_INFOPLIST_FILE=YES"
            echo "     Consider removing it: rm \"$dir/Info.plist\""
            WARNINGS=$((WARNINGS + 1))
        fi
    done
fi

# Check 3: Verify GENERATE_INFOPLIST_FILE is set
echo "✓ Checking for Info.plist generation setting..."

if [ "$HAS_GENERATE_INFOPLIST" -eq 0 ]; then
    echo "  ⚠️  WARNING: GENERATE_INFOPLIST_FILE not found"
    echo "     Modern Xcode projects should auto-generate Info.plist"
    WARNINGS=$((WARNINGS + 1))
else
    echo "  ✅ GENERATE_INFOPLIST_FILE is set"
fi

# Check 4: Verify deployment target is set
echo "✓ Checking deployment target..."

HAS_DEPLOYMENT_TARGET=$(grep -c "IPHONEOS_DEPLOYMENT_TARGET\|MACOSX_DEPLOYMENT_TARGET" "$PBXPROJ" || true)

if [ "$HAS_DEPLOYMENT_TARGET" -eq 0 ]; then
    echo "  ⚠️  WARNING: No deployment target found"
    echo "     Set IPHONEOS_DEPLOYMENT_TARGET or MACOSX_DEPLOYMENT_TARGET"
    WARNINGS=$((WARNINGS + 1))
else
    echo "  ✅ Deployment target is set"
fi

# Check 5: Verify Swift version
echo "✓ Checking Swift version..."

HAS_SWIFT_VERSION=$(grep -c "SWIFT_VERSION" "$PBXPROJ" || true)

if [ "$HAS_SWIFT_VERSION" -eq 0 ]; then
    echo "  ⚠️  WARNING: SWIFT_VERSION not set"
    WARNINGS=$((WARNINGS + 1))
else
    echo "  ✅ Swift version is set"
fi

# Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ $ERRORS -gt 0 ]; then
    echo "❌ Validation FAILED with $ERRORS error(s) and $WARNINGS warning(s)"
    echo ""
    echo "Please fix errors before building the project."
    exit 1
elif [ $WARNINGS -gt 0 ]; then
    echo "⚠️  Validation completed with $WARNINGS warning(s)"
    echo ""
    echo "Project should build, but consider addressing warnings."
    exit 0
else
    echo "✅ Validation PASSED - No issues found"
    echo ""
    echo "Project is ready to build!"
    exit 0
fi
