# Haptic — Takeaway: iteration 7

> Source spec: `../archive/v007-2026-04-27-0813-verify.md` (converged 2026-04-27 at SHA `8e86d37`)
> Implementation verified: 2026-04-27 (report: `archive/v007-2026-04-27-0813-verify.md`)
> Verdict: PASS

## Shipped state `[from-code]`

**Entry point and app structure**
- SwiftUI `@main HapticApp` struct with `@UIApplicationDelegateAdaptor(AppDelegate.self)`; scene lifecycle routed via `SceneDelegate` → `AppCoordinator`. (`haptic/App/HapticApp.swift`, `haptic/App/AppDelegate.swift`)
- `AppCoordinator` is `@MainActor public final class` owning the root `UIWindow` and a `UITabBarController` (Contacts=0, Conversations=1 default, Settings=2). Auth-state changes trigger root view controller swaps via `showAuth()` / `showMainApp()`. (`haptic/App/AppCoordinator.swift`)
- Auth loop: `async for await` over `supabaseClient.auth.authStateChanges`, handling `.signedIn`, `.tokenRefreshed`, `.initialSession`, `.signedOut`; expired-JWT recovery via `attemptSessionRecovery()`. (`haptic/App/AppCoordinator.swift`)
- Invite URL deduplication via `resolvingInviteCodes: Set<String>`; early return if code already in-flight; code removed after resolution. Guards against dual-delivery from SceneDelegate and SwiftUI `onOpenURL`. (`haptic/App/AppCoordinator.swift`)
- `AppDependencies` is `@MainActor public final class`; single manual `init()` wires all 8 repositories, 8 use cases, `hapticPlayer`, `LocalDataSource`, and `NetworkMonitor`. No DI framework. (`haptic/App/AppDependencies.swift`)
- Haptic engine: compile-time `#if targetEnvironment(simulator)` selects `MockHapticPlayer` vs `CoreHapticsEngine`, both behind `HapticPlayable`. (`haptic/App/AppDependencies.swift`)

**HapticKit domain and data**
- Local SPM package with strict Domain/Data separation: `Sources/Domain/` (pure Swift, zero external deps) and `Sources/Data/` (Supabase + SwiftData adapters). (`HapticKit/Sources/`)
- `Message.Content` enum has exactly two cases: `.haptic(sequence: HapticSequence, label: String?, icon: String?)` and `.text(String)`. (`HapticKit/Sources/Domain/Entities/Message.swift`)
- All 8 value objects present including `HapticPattern` with `icon: String` (SF Symbol name). (`HapticKit/Sources/Domain/ValueObjects/`)
- `LocalMessage` SwiftData `@Model` persists `displayModality`, `cachedMorseHapticData`, `playState`, and `hapticIcon` beyond raw Supabase fields. (`HapticKit/Sources/Data/Local/SwiftDataModels/LocalMessage.swift`)
- Realtime channel logic consolidated in `SupabaseRealtimeRepository.swift` with deliberate-consolidation header comment; no separate `ConversationChannel.swift`. Broadcast DTOs: `LiveTouchBroadcastDTO`, `PatternBroadcastDTO` (with `label` + `icon`), `SessionCompleteBroadcastDTO`. (`HapticKit/Sources/Data/Repositories/SupabaseRealtimeRepository.swift`, `HapticKit/Sources/Data/Remote/RealtimeChannel/LiveTouchBroadcast.swift`)

**Presentation and chat**
- `ChatViewModel` is `@MainActor ObservableObject` with `@Published` properties; session completion timeout 2 s; safety timeout 4 s (deliberate tuning). (`haptic/Presentation/Chat/ChatViewModel.swift`)
- `TapInputView` is a UIKit `UIView` using synchronous `touchesBegan/Ended`, `CACurrentMediaTime()` timestamps, `isMultipleTouchEnabled = false` (strict single-touch), and direct feed to effect layers. (`haptic/Presentation/Chat/TapInputView.swift`)
- Reactive pulsing border for live incoming touches: `ChatViewModel.onPartnerTouchEvent` callback → `ChatViewController.setupReactiveBorder()` → `animateGlowForTouchEvent`. (`haptic/Presentation/Chat/ChatViewModel.swift`, `haptic/Presentation/Chat/ChatViewController.swift`)
- Message pagination: `loadOlderMessages()` fetches 50 messages before cursor date; `hasMoreOlderMessages` flag controls infinite scroll on scroll-to-top. (`haptic/Presentation/Chat/ChatViewModel.swift`, `haptic/Presentation/Chat/ChatViewController.swift`)
- Per-message play state (unplayed / playing / played) written to SwiftData via `LocalDataSource.updateMessagePlayState()` and reloaded in `loadLocalMessages()` on next launch. (`haptic/Presentation/Chat/ChatViewModel.swift`)
- `newMessageIndicator` floating button shown when `!wasNearBottom` on new message arrival; hides after scroll-to-bottom. (`haptic/Presentation/Chat/ChatViewController.swift`)

**Theme system**
- `ThemeProvider` is `@MainActor final class`: `ObservableObject + @Published` for SwiftUI (`@ObservedObject` in `SettingsView`); `NotificationCenter` post of `themeDidChangeNotification` for UIKit (`applyTheme()` in `AppCoordinator` and view controllers). Persists selection to `UserDefaults`. (`haptic/Presentation/Theme/ThemeProvider.swift`)
- `HapticTheme` is a `@MainActor enum` facade delegating all properties to `ThemeProvider.shared.current`. (`haptic/Presentation/HapticTheme.swift`)
- Four concrete themes: `BioluminescentTheme`, `DeepBloomTheme`, `ArcadeTheme`, `BrutalistTheme`. Per-theme visual effects: `DeepBloomBackgroundView` (CAEmitterLayer + CoreMotion parallax) and `ArcadeEffectsView` (radial CAGradientLayer bloom) inserted at view index 0; `tableView.backgroundColor = .clear` when active. (`haptic/Presentation/Chat/Effects/`)

**Settings, debug, and auth**
- `SettingsView` is SwiftUI, no `SettingsViewModel`; subscribes via `@ObservedObject ThemeProvider.shared`. Contains unconditional `debugSection` (NavigationLink to `RealtimeLogView`) and unconditional `accountSection` (Sign Out). (`haptic/Presentation/Settings/SettingsView.swift`)
- `RealtimeLogStore` (200-entry in-memory circular buffer) and `RealtimeLogView` are not `#if DEBUG`-gated — retained in release for user bug reports. (`haptic/Infrastructure/RealtimeLogStore.swift`, `haptic/Presentation/Settings/RealtimeLogView.swift`)
- `AuthViewController` is a pure `UIHostingController<AuthView>` with no UIKit logic. `AuthViewModel` is `@MainActor @Observable` (SwiftUI-exclusive). (`haptic/Presentation/Auth/`)

**Backend**
- 8 migration files spanning 2026-03-03 through 2026-03-12. Most recent (`20260311210000_add_haptic_icon.sql`) adds `haptic_icon` column — set only for pattern-origin haptics; free-tap messages leave it null and render a generic "waveform" icon. (`supabase/migrations/`)
- RLS enabled on all 6 tables. Realtime enabled for `messages` and `contacts` via explicit migration adding them to the `supabase_realtime` publication. (`supabase/migrations/20260306130000_enable_realtime.sql`)

## Deviations from spec

### Accepted gaps
(none)

### Other deviations
**AC8.1 — `debugSection` gating:** The spec-as-written stated `debugSection` was `#if DEBUG`-gated, but the code has it unconditional (matching AC8.2's correct description of `RealtimeLogView` being release-retained for user bug reports). This was a spec inconsistency, not a code defect. Resolved by spec commit 8e86d37 updating AC8.1 to describe `debugSection` as unconditional. No code change was required or made.

**AC7.3 — Arcade effect view placement:** The spec says effect views are inserted "at view index 0"; `ArcadeEffectsView` is actually inserted `aboveSubview: inputContainer` per an inline comment about needing to appear above the input area. Behavioral intent (behind content, `isUserInteractionEnabled = false`) is met. Noted in the verify report; not flagged as a blocking gap.

## Discoveries during implementation

- **Dual-framework observation pattern.** `@Observable` (Swift Observation framework, iOS 17+) is SwiftUI-only — it exposes no Combine `objectWillChange` / `@Published` / `NotificationCenter` channel that UIKit can subscribe to. Any service that must drive both frameworks requires `ObservableObject + @Published + NotificationCenter`. This is now invariant #7 and documented in the app-level CLAUDE.md. (`haptic/Presentation/Theme/ThemeProvider.swift` is the canonical example.)
- **Mechanism-only CLAUDE.md principle.** Documentation that lists catalog content (file inventories, entity enumerations, theme tables, enabled-feature lists) becomes stale on the first refactor and creates silent misleading context for future sessions. The rule-of-thumb test: "would this line need updating if code changed but the principle didn't?" If yes, it's catalog — name the register in code and stop. Adopted as invariant #18, now an explicit section in `haptic-app/CLAUDE.md`.
- **Spec-vs-code divergence pattern.** The rough spec that existed before this adoption iteration had accumulated several false claims (e.g., "no SwiftUI `@main` App struct" when `HapticApp.swift` exists; Sign Out gated `#if DEBUG` when it is unconditional). Adoption iterations should expect 3-6 such divergences and budget time for the reconciliation read. Resolving at the spec level (fix the doc, not the code) is often the right call.
- **Safety timeout was already tuned.** The 2-second session timeout in spec was not the only timeout — a 4-second safety timeout for receivers also existed and was already tuned from an earlier 2-second default to handle long-press interactions. The spec had to capture both to avoid future confusion.
- **Debug credentials in spec.** AC6.3 initially included the literal test password. Removed on review — credentials should live in source behind the DEBUG gate, not in a spec document that may travel outside the repo.
- **Line-number suffixes in spec source pointers drift.** The original Current State block used `:NN-MM` line-range suffixes on file paths. Stripped on review: symbol names and file paths are durable grep targets across refactors; line numbers are not.

## Key decisions (this iteration)
See `../decisions.log` under the `# Iteration 7` header. Load-bearing ones summarized:

- **Realtime channel consolidation kept.** All realtime channel logic (subscribe, broadcast, receive, channel lifecycle) stays in `SupabaseRealtimeRepository.swift`. Alternatives (extract as Supabase wrapper, extract as domain-level protocol) were considered and rejected for simplicity. Revisit only if a second transport or isolated channel tests are needed.
- **Dual-framework observation recipe formalized.** `ObservableObject + @Published + NotificationCenter` is the required pattern for any observable service bridging both SwiftUI and UIKit. Promoted from implicit app knowledge to explicit invariant and CLAUDE.md rule (decision 2026-04-23).
- **Mechanism-only CLAUDE.md doctrine adopted.** Cluster 6 audit (17 edits across 5 CLAUDE.md files) applied this principle: pruned catalog/state leaks from all CLAUDE.md files, retained invariants and mechanism rules. The doctrine is now self-enforcing via invariant #18 (decision 2026-04-24).
- **NetworkMonitor discard-on-loss demoted to Test-pending.** The code path exists and is correct, but behavioral verification (force-disable mid-tap, confirm no partial broadcast) was not completed this iteration. Ratifying an unproven path as a full invariant would canonize a guarantee that hadn't been tested. Scheduled for iteration 8.
- **AC structure: subsystem-grouped, not tag-grouped.** MECE tree organized by subsystem (Architecture, HapticKit, Presentation, etc.) rather than grouping all `[adopted]` together and all `[delta]` together. CLAUDE.md `[delta]` ACs grouped by file (AC11–AC15) rather than by Cluster 6 item number — makes future per-subsystem verify passes independent of the Cluster 6 inventory.

## Open for next iteration

**Scheduled deferrals (from decisions.log `[iteration-scope]`):**
- **`SettingsViewModel` extraction.** Settings currently has no logic beyond theme switching; `SettingsView` subscribes directly to `ThemeProvider.shared`. Extract when Settings gains non-trivial logic. (Decision 2026-04-23.)
- **Theme catalog changes.** Planned: add dark glassmorphic theme, merge bioluminescent-family themes, possibly remove Brutalist. Theme mechanism is stable; catalog is point-in-time. (Decision 2026-04-24.)
- **Invite system overhaul.** Planned: reusable multi-invitee invite links (current: single-use). Dedup invariant is permanent across the redesign. (Decision 2026-04-24.)
- **`RealtimeLogView` UX polish.** Filtering, export, improved UI. Retained in release unconditionally; polish deferred until bug-report volume justifies investment. (Decision 2026-04-24.)
- **`HapticWaveformView` improvements.** Current SwiftUI `TimelineView` + `Canvas` implementation is complete and integrated; visual polish deferred. (Decision 2026-04-24.)

**Test-pending (from `## Test-pending` in spec.md):**
- **NetworkMonitor discard-on-loss behavioral verification.** Force-disable network mid-tap → confirm session discarded → confirm no partial broadcast sent → characterize user-visible feedback (if any). On pass, promote to a full invariant. Code path in `ChatViewModel` + `NetworkMonitor` exists; path is thinly exercised in practice. Must be completed in iteration 8.
